﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCustomModeSetupMultiplication
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnContinue = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.cmbMatrixSize = New System.Windows.Forms.ComboBox()
        Me.txtQuestionsToSolve = New System.Windows.Forms.TextBox()
        Me.txtLowerBound = New System.Windows.Forms.TextBox()
        Me.txtUpperBound = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnContinue
        '
        Me.btnContinue.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnContinue.Location = New System.Drawing.Point(102, 273)
        Me.btnContinue.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnContinue.Name = "btnContinue"
        Me.btnContinue.Size = New System.Drawing.Size(70, 34)
        Me.btnContinue.TabIndex = 5
        Me.btnContinue.Text = "Continue"
        Me.btnContinue.UseVisualStyleBackColor = True
        '
        'btnBack
        '
        Me.btnBack.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(177, 273)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(70, 34)
        Me.btnBack.TabIndex = 6
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'cmbMatrixSize
        '
        Me.cmbMatrixSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbMatrixSize.FormattingEnabled = True
        Me.cmbMatrixSize.Items.AddRange(New Object() {"(2x3) x (3x2)", "(3x2) x (2x3)", "(3x3) x (3x3)"})
        Me.cmbMatrixSize.Location = New System.Drawing.Point(123, 236)
        Me.cmbMatrixSize.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.cmbMatrixSize.Name = "cmbMatrixSize"
        Me.cmbMatrixSize.Size = New System.Drawing.Size(92, 21)
        Me.cmbMatrixSize.TabIndex = 4
        Me.cmbMatrixSize.TabStop = False
        '
        'txtQuestionsToSolve
        '
        Me.txtQuestionsToSolve.Location = New System.Drawing.Point(143, 63)
        Me.txtQuestionsToSolve.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtQuestionsToSolve.MaxLength = 3
        Me.txtQuestionsToSolve.Name = "txtQuestionsToSolve"
        Me.txtQuestionsToSolve.Size = New System.Drawing.Size(52, 20)
        Me.txtQuestionsToSolve.TabIndex = 1
        '
        'txtLowerBound
        '
        Me.txtLowerBound.Location = New System.Drawing.Point(125, 156)
        Me.txtLowerBound.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtLowerBound.MaxLength = 4
        Me.txtLowerBound.Name = "txtLowerBound"
        Me.txtLowerBound.Size = New System.Drawing.Size(38, 20)
        Me.txtLowerBound.TabIndex = 2
        '
        'txtUpperBound
        '
        Me.txtUpperBound.Location = New System.Drawing.Point(252, 156)
        Me.txtUpperBound.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtUpperBound.MaxLength = 4
        Me.txtUpperBound.Name = "txtUpperBound"
        Me.txtUpperBound.Size = New System.Drawing.Size(37, 20)
        Me.txtUpperBound.TabIndex = 3
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(175, 158)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(73, 13)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = "Upper Bound:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(49, 158)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(73, 13)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "Lower Bound:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(22, 207)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(294, 17)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "What size matrices would you like to multiply?"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(40, 116)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(288, 17)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Specify the ranges for elements in the array:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(40, 37)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(291, 17)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "How many questions would you like to solve?"
        '
        'frmCustomModeSetupMultiplication
        '
        Me.AcceptButton = Me.btnContinue
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.CancelButton = Me.btnBack
        Me.ClientSize = New System.Drawing.Size(339, 344)
        Me.Controls.Add(Me.btnContinue)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.cmbMatrixSize)
        Me.Controls.Add(Me.txtQuestionsToSolve)
        Me.Controls.Add(Me.txtLowerBound)
        Me.Controls.Add(Me.txtUpperBound)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "frmCustomModeSetupMultiplication"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Custom Multiplication Setup"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnContinue As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents cmbMatrixSize As ComboBox
    Friend WithEvents txtQuestionsToSolve As TextBox
    Friend WithEvents txtLowerBound As TextBox
    Friend WithEvents txtUpperBound As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
