﻿Public Class frmSubMatrices4x4
    Dim C1 As Decimal
    Dim C2 As Decimal
    Dim C3 As Decimal
    Dim C4 As Decimal
    Dim C5 As Decimal
    Dim C6 As Decimal
    Dim C7 As Decimal
    Dim C8 As Decimal
    Dim C9 As Decimal
    Dim C10 As Decimal
    Dim C11 As Decimal
    Dim C12 As Decimal
    Dim C13 As Decimal
    Dim C14 As Decimal
    Dim C15 As Decimal
    Dim C16 As Decimal

    Public Property correct As Boolean = False
    Dim i As Integer = 0
    Dim questionsToSolve As Integer = frmCustomModeSetupSubtraction.questionsToSolve
    Dim lowerBound As Integer = frmCustomModeSetupSubtraction.lowerBound
    Dim upperBound As Integer = frmCustomModeSetupSubtraction.upperBound
    Public Property isStory As Boolean = False
    Public Property isStoryDone As Boolean = False
    Public Property storyCounter As Integer = 2
    'Compares the inputed text boxes to correct answer and displays correct or incorrect message accordingly
    'Checks to see if problem cam from story and handles that accordingly
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        If isStory = False Then

            Try
                If C1.Equals(CDec(txtC1.Text)) And C2.Equals(CDec(txtC2.Text)) And C3.Equals(CDec(txtC3.Text)) And C4.Equals(CDec(txtC4.Text)) And C5.Equals(CDec(txtC5.Text)) And C6.Equals(CDec(txtC6.Text)) And C7.Equals(CDec(txtC7.Text)) And C8.Equals(CDec(txtC8.Text)) And C9.Equals(CDec(txtC9.Text)) Then
                    correct = True
                Else
                    correct = False
                End If

                If correct = True Then
                    Dim message As String = "You got it correct."
                    Dim caption As String = "Correct!"
                    Dim button As MessageBoxButtons = MessageBoxButtons.OK
                    Dim correctMessage As DialogResult
                    correctMessage = MessageBox.Show(message, caption, button)
                    i += 1

                Else
                    Dim message As String = "You got it incorrect."
                    Dim caption As String = "Incorrect!"
                    Dim button As MessageBoxButtons = MessageBoxButtons.OK
                    Dim incorrectMessage As DialogResult
                    incorrectMessage = MessageBox.Show(message, caption, button)
                    i += 1
                End If

                If i = questionsToSolve And frmLevelSelection.isStory = False Then
                    Dim message2 As String = "You completed all questions."
                    Dim caption2 As String = "Complete!"
                    Dim button2 As MessageBoxButtons = MessageBoxButtons.OK
                    Dim completeMessage As DialogResult
                    completeMessage = MessageBox.Show(message2, caption2, button2)

                    frmLevelSelection.Show()
                    Me.Close()
                End If

                frmSubMatrices4x4_Load(e, e)
                txtC1.Clear()
                txtC2.Clear()
                txtC3.Clear()
                txtC4.Clear()
                txtC5.Clear()
                txtC6.Clear()
                txtC7.Clear()
                txtC8.Clear()
                txtC9.Clear()
                txtC1.Focus()
            Catch ex As InvalidCastException
                MessageBox.Show("Please enter only numbers.", "Error")
            Catch ex As ArgumentException
                MessageBox.Show("Please enter only numbers.", "Error")
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.StackTrace)
            End Try
        Else

            Try
                If C1.Equals(CDec(txtC1.Text)) And C2.Equals(CDec(txtC2.Text)) And C3.Equals(CDec(txtC3.Text)) And C4.Equals(CDec(txtC4.Text)) And C5.Equals(CDec(txtC5.Text)) And C6.Equals(CDec(txtC6.Text)) And C7.Equals(CDec(txtC7.Text)) And C8.Equals(CDec(txtC8.Text)) And C9.Equals(CDec(txtC9.Text)) Then
                    correct = True
                Else
                    correct = False
                End If

                If correct = True Then
                    Dim message As String = "You got it correct."
                    Dim caption As String = "Correct!"
                    Dim button As MessageBoxButtons = MessageBoxButtons.OK
                    Dim correctMessage As DialogResult
                    correctMessage = MessageBox.Show(message, caption, button)
                    i += 1

                    frmStoryModeExecution.counter += 1
                    frmStoryModeExecution.btnNextQuestion.Enabled = True
                    Me.Close()
                Else
                    Dim message As String = "You got it incorrect."
                    Dim caption As String = "Incorrect!"
                    Dim button As MessageBoxButtons = MessageBoxButtons.OK
                    Dim incorrectMessage As DialogResult
                    incorrectMessage = MessageBox.Show(message, caption, button)
                    i += 1
                End If

                frmSubMatrices4x4_Load(e, e)
                txtC1.Clear()
                txtC2.Clear()
                txtC3.Clear()
                txtC4.Clear()
                txtC5.Clear()
                txtC6.Clear()
                txtC7.Clear()
                txtC8.Clear()
                txtC9.Clear()
                txtC10.Clear()
                txtC11.Clear()
                txtC12.Clear()
                txtC13.Clear()
                txtC14.Clear()
                txtC15.Clear()
                txtC16.Clear()
                txtC1.Focus()
            Catch ex As InvalidCastException
                MessageBox.Show("Please enter only numbers.", "Error")
            Catch ex As ArgumentException
                MessageBox.Show("Please enter only numbers.", "Error")
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.StackTrace)
            End Try
        End If
    End Sub
    'Creates a random matrix problem using specified bounds
    Private Sub frmSubMatrices4x4_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        txtA1.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA2.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA3.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA4.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA5.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA6.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA7.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA8.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA9.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA10.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA11.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA12.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA13.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA14.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA15.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA16.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString

        txtB1.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtB2.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtB3.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtB4.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtB5.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtB6.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtB7.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtB8.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtB9.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtB10.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtB11.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtB12.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtB13.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtB14.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtB15.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtB16.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString

        C1 = (CDec(txtA1.Text) - CDec(txtB1.Text))
        C2 = (CDec(txtA2.Text) - CDec(txtB2.Text))
        C3 = (CDec(txtA3.Text) - CDec(txtB3.Text))
        C4 = (CDec(txtA4.Text) - CDec(txtB4.Text))
        C5 = (CDec(txtA5.Text) - CDec(txtB5.Text))
        C6 = (CDec(txtA6.Text) - CDec(txtB6.Text))
        C7 = (CDec(txtA7.Text) - CDec(txtB7.Text))
        C8 = (CDec(txtA8.Text) - CDec(txtB8.Text))
        C9 = (CDec(txtA9.Text) - CDec(txtB9.Text))
        C10 = (CDec(txtA10.Text) - CDec(txtB10.Text))
        C11 = (CDec(txtA11.Text) - CDec(txtB11.Text))
        C12 = (CDec(txtA12.Text) - CDec(txtB12.Text))
        C13 = (CDec(txtA13.Text) - CDec(txtB13.Text))
        C14 = (CDec(txtA14.Text) - CDec(txtB14.Text))
        C15 = (CDec(txtA15.Text) - CDec(txtB15.Text))
        C16 = (CDec(txtA16.Text) - CDec(txtB16.Text))
    End Sub
    'Returns back to custom mode setup screen
    Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        frmCustomModeSetup.Show()
        Me.Close()
    End Sub
    'Dislpays help dialog box for subtraction
    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        dlgHelpSubtraction.Show()
    End Sub
End Class