﻿Imports System.IO
Imports System.IO.File
Public Class frmStoryModeLoad
    Dim numLines As Integer = File.ReadAllLines("StoryModeInfo.txt").Length
    Dim names(numLines) As String
    Dim user As Integer
    Dim positions(numLines) As Integer
    Public Property position As Integer
    'Returns back the the story mode main menu
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        frmStoryModeSelect.Show()
        Me.Close()
    End Sub
    'Loads the names and positions of all users into an array
    'Catches excepted if specified name is not in array
    Private Sub btnLoad_Click(sender As Object, e As EventArgs) Handles btnLoad.Click
        Try
            Dim path As String = My.Application.Info.DirectoryPath
            Dim path2 As String = IO.Path.Combine(path, "StoryModeInfo.txt")

            Dim reader2 As New StreamReader("StoryModeInfo.txt")
            For q As Integer = 0 To numLines - 1
                Dim line As String = reader2.ReadLine()
                names(q) = (line).Substring(0, (line).IndexOf("Level: ") - 1)
                positions(q) = CInt((line).Substring((line).IndexOf("Level: ") + 6, (line).Length - ((line).IndexOf("Level: ") + 6)))
            Next
            reader2.Close()
            user = Array.IndexOf(names, txtUserName.Text)
            position = positions(user)
            frmStoryModeExecution.counter = position
            frmStoryModeExecution.Show()
            Me.Hide()
        Catch ex As IndexOutOfRangeException
            MessageBox.Show("Username not found in save files.", "Error - Try again")
        End Try
    End Sub
    'rewrites files with updated position for the new position
    Public Sub writeFile()
        positions(user) = position
        Dim names2() As String = names
        My.Computer.FileSystem.DeleteFile("StoryModeInfo.txt")
        Dim file2 As System.IO.StreamWriter
        Dim path3 As String = My.Application.Info.DirectoryPath
        Dim path4 As String = IO.Path.Combine(path3, "StoryModeInfo.txt")
        file2 = My.Computer.FileSystem.OpenTextFileWriter(path4, True)
        For q As Integer = 0 To names.Length - 2
            file2.WriteLine(names2(q) & " Level: " & positions(q))
        Next q
        file2.Close()
    End Sub
End Class