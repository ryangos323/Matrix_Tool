﻿Public Class frmStoryModeNew
    'Returns back to the main story mode menu when the back button is clicked
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        frmStoryModeSelect.Show()
        Me.Close()
    End Sub
    'Saves the username plus level 0 to the text files indicating a new user
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim file As System.IO.StreamWriter
        Dim word As String = txtUserName.Text
        Dim path As String = My.Application.Info.DirectoryPath
        Dim path2 As String = IO.Path.Combine(path, "StoryModeInfo.txt")
        file = My.Computer.FileSystem.OpenTextFileWriter(path2, True)
        file.WriteLine(word & " Level: 0")
        file.Close()
        txtUserName.Clear()
        frmStoryModeExecution.counter = 0
        frmStoryModeLoad.Show()
        Me.Close()
    End Sub
End Class