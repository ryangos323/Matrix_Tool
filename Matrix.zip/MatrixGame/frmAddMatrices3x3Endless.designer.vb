﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddMatrices3x3Endless
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtA1 = New System.Windows.Forms.TextBox()
        Me.txtA9 = New System.Windows.Forms.TextBox()
        Me.txtA7 = New System.Windows.Forms.TextBox()
        Me.txtA6 = New System.Windows.Forms.TextBox()
        Me.txtA5 = New System.Windows.Forms.TextBox()
        Me.txtA4 = New System.Windows.Forms.TextBox()
        Me.txtA3 = New System.Windows.Forms.TextBox()
        Me.txtA2 = New System.Windows.Forms.TextBox()
        Me.txtA8 = New System.Windows.Forms.TextBox()
        Me.txtB8 = New System.Windows.Forms.TextBox()
        Me.txtB2 = New System.Windows.Forms.TextBox()
        Me.txtB3 = New System.Windows.Forms.TextBox()
        Me.txtB4 = New System.Windows.Forms.TextBox()
        Me.txtB5 = New System.Windows.Forms.TextBox()
        Me.txtB6 = New System.Windows.Forms.TextBox()
        Me.txtB7 = New System.Windows.Forms.TextBox()
        Me.txtB9 = New System.Windows.Forms.TextBox()
        Me.txtB1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.btnHelp = New System.Windows.Forms.Button()
        Me.txtC8 = New System.Windows.Forms.TextBox()
        Me.txtC2 = New System.Windows.Forms.TextBox()
        Me.txtC3 = New System.Windows.Forms.TextBox()
        Me.txtC4 = New System.Windows.Forms.TextBox()
        Me.txtC5 = New System.Windows.Forms.TextBox()
        Me.txtC6 = New System.Windows.Forms.TextBox()
        Me.txtC7 = New System.Windows.Forms.TextBox()
        Me.txtC9 = New System.Windows.Forms.TextBox()
        Me.txtC1 = New System.Windows.Forms.TextBox()
        Me.btnQuit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(55, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Matrix A:"
        '
        'txtA1
        '
        Me.txtA1.Location = New System.Drawing.Point(58, 84)
        Me.txtA1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtA1.Name = "txtA1"
        Me.txtA1.ReadOnly = True
        Me.txtA1.Size = New System.Drawing.Size(73, 22)
        Me.txtA1.TabIndex = 1
        Me.txtA1.TabStop = False
        '
        'txtA9
        '
        Me.txtA9.Location = New System.Drawing.Point(218, 139)
        Me.txtA9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtA9.Name = "txtA9"
        Me.txtA9.ReadOnly = True
        Me.txtA9.Size = New System.Drawing.Size(73, 22)
        Me.txtA9.TabIndex = 2
        Me.txtA9.TabStop = False
        '
        'txtA7
        '
        Me.txtA7.Location = New System.Drawing.Point(58, 139)
        Me.txtA7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtA7.Name = "txtA7"
        Me.txtA7.ReadOnly = True
        Me.txtA7.Size = New System.Drawing.Size(73, 22)
        Me.txtA7.TabIndex = 3
        Me.txtA7.TabStop = False
        '
        'txtA6
        '
        Me.txtA6.Location = New System.Drawing.Point(218, 111)
        Me.txtA6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtA6.Name = "txtA6"
        Me.txtA6.ReadOnly = True
        Me.txtA6.Size = New System.Drawing.Size(73, 22)
        Me.txtA6.TabIndex = 4
        Me.txtA6.TabStop = False
        '
        'txtA5
        '
        Me.txtA5.Location = New System.Drawing.Point(138, 111)
        Me.txtA5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtA5.Name = "txtA5"
        Me.txtA5.ReadOnly = True
        Me.txtA5.Size = New System.Drawing.Size(73, 22)
        Me.txtA5.TabIndex = 5
        Me.txtA5.TabStop = False
        '
        'txtA4
        '
        Me.txtA4.Location = New System.Drawing.Point(58, 111)
        Me.txtA4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtA4.Name = "txtA4"
        Me.txtA4.ReadOnly = True
        Me.txtA4.Size = New System.Drawing.Size(73, 22)
        Me.txtA4.TabIndex = 6
        Me.txtA4.TabStop = False
        '
        'txtA3
        '
        Me.txtA3.Location = New System.Drawing.Point(218, 84)
        Me.txtA3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtA3.Name = "txtA3"
        Me.txtA3.ReadOnly = True
        Me.txtA3.Size = New System.Drawing.Size(73, 22)
        Me.txtA3.TabIndex = 7
        Me.txtA3.TabStop = False
        '
        'txtA2
        '
        Me.txtA2.Location = New System.Drawing.Point(138, 84)
        Me.txtA2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtA2.Name = "txtA2"
        Me.txtA2.ReadOnly = True
        Me.txtA2.Size = New System.Drawing.Size(73, 22)
        Me.txtA2.TabIndex = 8
        Me.txtA2.TabStop = False
        '
        'txtA8
        '
        Me.txtA8.Location = New System.Drawing.Point(138, 139)
        Me.txtA8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtA8.Name = "txtA8"
        Me.txtA8.ReadOnly = True
        Me.txtA8.Size = New System.Drawing.Size(73, 22)
        Me.txtA8.TabIndex = 9
        Me.txtA8.TabStop = False
        '
        'txtB8
        '
        Me.txtB8.Location = New System.Drawing.Point(476, 139)
        Me.txtB8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtB8.Name = "txtB8"
        Me.txtB8.ReadOnly = True
        Me.txtB8.Size = New System.Drawing.Size(73, 22)
        Me.txtB8.TabIndex = 19
        Me.txtB8.TabStop = False
        '
        'txtB2
        '
        Me.txtB2.Location = New System.Drawing.Point(476, 84)
        Me.txtB2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtB2.Name = "txtB2"
        Me.txtB2.ReadOnly = True
        Me.txtB2.Size = New System.Drawing.Size(73, 22)
        Me.txtB2.TabIndex = 18
        Me.txtB2.TabStop = False
        '
        'txtB3
        '
        Me.txtB3.Location = New System.Drawing.Point(556, 84)
        Me.txtB3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtB3.Name = "txtB3"
        Me.txtB3.ReadOnly = True
        Me.txtB3.Size = New System.Drawing.Size(73, 22)
        Me.txtB3.TabIndex = 17
        Me.txtB3.TabStop = False
        '
        'txtB4
        '
        Me.txtB4.Location = New System.Drawing.Point(396, 111)
        Me.txtB4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtB4.Name = "txtB4"
        Me.txtB4.ReadOnly = True
        Me.txtB4.Size = New System.Drawing.Size(73, 22)
        Me.txtB4.TabIndex = 16
        Me.txtB4.TabStop = False
        '
        'txtB5
        '
        Me.txtB5.Location = New System.Drawing.Point(476, 111)
        Me.txtB5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtB5.Name = "txtB5"
        Me.txtB5.ReadOnly = True
        Me.txtB5.Size = New System.Drawing.Size(73, 22)
        Me.txtB5.TabIndex = 15
        Me.txtB5.TabStop = False
        '
        'txtB6
        '
        Me.txtB6.Location = New System.Drawing.Point(556, 111)
        Me.txtB6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtB6.Name = "txtB6"
        Me.txtB6.ReadOnly = True
        Me.txtB6.Size = New System.Drawing.Size(73, 22)
        Me.txtB6.TabIndex = 14
        Me.txtB6.TabStop = False
        '
        'txtB7
        '
        Me.txtB7.Location = New System.Drawing.Point(396, 139)
        Me.txtB7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtB7.Name = "txtB7"
        Me.txtB7.ReadOnly = True
        Me.txtB7.Size = New System.Drawing.Size(73, 22)
        Me.txtB7.TabIndex = 13
        Me.txtB7.TabStop = False
        '
        'txtB9
        '
        Me.txtB9.Location = New System.Drawing.Point(556, 139)
        Me.txtB9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtB9.Name = "txtB9"
        Me.txtB9.ReadOnly = True
        Me.txtB9.Size = New System.Drawing.Size(73, 22)
        Me.txtB9.TabIndex = 12
        Me.txtB9.TabStop = False
        '
        'txtB1
        '
        Me.txtB1.Location = New System.Drawing.Point(396, 84)
        Me.txtB1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtB1.Name = "txtB1"
        Me.txtB1.ReadOnly = True
        Me.txtB1.Size = New System.Drawing.Size(73, 22)
        Me.txtB1.TabIndex = 11
        Me.txtB1.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(392, 39)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 25)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Matrix B:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(326, 96)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(36, 38)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "+"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(663, 96)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(36, 38)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "="
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(724, 39)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(173, 25)
        Me.Label5.TabIndex = 22
        Me.Label5.Text = "Solve for Matrix C:"
        '
        'btnSubmit
        '
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(327, 183)
        Me.btnSubmit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(103, 49)
        Me.btnSubmit.TabIndex = 10
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'btnHelp
        '
        Me.btnHelp.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHelp.Location = New System.Drawing.Point(456, 183)
        Me.btnHelp.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(103, 49)
        Me.btnHelp.TabIndex = 11
        Me.btnHelp.Text = "Help"
        Me.btnHelp.UseVisualStyleBackColor = True
        '
        'txtC8
        '
        Me.txtC8.Location = New System.Drawing.Point(807, 139)
        Me.txtC8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtC8.Name = "txtC8"
        Me.txtC8.Size = New System.Drawing.Size(73, 22)
        Me.txtC8.TabIndex = 8
        '
        'txtC2
        '
        Me.txtC2.Location = New System.Drawing.Point(807, 84)
        Me.txtC2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtC2.Name = "txtC2"
        Me.txtC2.Size = New System.Drawing.Size(73, 22)
        Me.txtC2.TabIndex = 2
        '
        'txtC3
        '
        Me.txtC3.Location = New System.Drawing.Point(887, 84)
        Me.txtC3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtC3.Name = "txtC3"
        Me.txtC3.Size = New System.Drawing.Size(73, 22)
        Me.txtC3.TabIndex = 3
        '
        'txtC4
        '
        Me.txtC4.Location = New System.Drawing.Point(727, 111)
        Me.txtC4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtC4.Name = "txtC4"
        Me.txtC4.Size = New System.Drawing.Size(73, 22)
        Me.txtC4.TabIndex = 4
        '
        'txtC5
        '
        Me.txtC5.Location = New System.Drawing.Point(807, 111)
        Me.txtC5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtC5.Name = "txtC5"
        Me.txtC5.Size = New System.Drawing.Size(73, 22)
        Me.txtC5.TabIndex = 5
        '
        'txtC6
        '
        Me.txtC6.Location = New System.Drawing.Point(887, 111)
        Me.txtC6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtC6.Name = "txtC6"
        Me.txtC6.Size = New System.Drawing.Size(73, 22)
        Me.txtC6.TabIndex = 6
        '
        'txtC7
        '
        Me.txtC7.Location = New System.Drawing.Point(727, 139)
        Me.txtC7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtC7.Name = "txtC7"
        Me.txtC7.Size = New System.Drawing.Size(73, 22)
        Me.txtC7.TabIndex = 7
        '
        'txtC9
        '
        Me.txtC9.Location = New System.Drawing.Point(887, 139)
        Me.txtC9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtC9.Name = "txtC9"
        Me.txtC9.Size = New System.Drawing.Size(73, 22)
        Me.txtC9.TabIndex = 9
        '
        'txtC1
        '
        Me.txtC1.Location = New System.Drawing.Point(727, 84)
        Me.txtC1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtC1.Name = "txtC1"
        Me.txtC1.Size = New System.Drawing.Size(73, 22)
        Me.txtC1.TabIndex = 1
        '
        'btnQuit
        '
        Me.btnQuit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnQuit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuit.Location = New System.Drawing.Point(585, 183)
        Me.btnQuit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(103, 49)
        Me.btnQuit.TabIndex = 12
        Me.btnQuit.Text = "Quit"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'frmAddMatrices3x3
        '
        Me.AcceptButton = Me.btnSubmit
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.CancelButton = Me.btnQuit
        Me.ClientSize = New System.Drawing.Size(1015, 270)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.txtC8)
        Me.Controls.Add(Me.txtC2)
        Me.Controls.Add(Me.txtC3)
        Me.Controls.Add(Me.txtC4)
        Me.Controls.Add(Me.txtC5)
        Me.Controls.Add(Me.txtC6)
        Me.Controls.Add(Me.txtC7)
        Me.Controls.Add(Me.txtC9)
        Me.Controls.Add(Me.txtC1)
        Me.Controls.Add(Me.btnHelp)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtB8)
        Me.Controls.Add(Me.txtB2)
        Me.Controls.Add(Me.txtB3)
        Me.Controls.Add(Me.txtB4)
        Me.Controls.Add(Me.txtB5)
        Me.Controls.Add(Me.txtB6)
        Me.Controls.Add(Me.txtB7)
        Me.Controls.Add(Me.txtB9)
        Me.Controls.Add(Me.txtB1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtA8)
        Me.Controls.Add(Me.txtA2)
        Me.Controls.Add(Me.txtA3)
        Me.Controls.Add(Me.txtA4)
        Me.Controls.Add(Me.txtA5)
        Me.Controls.Add(Me.txtA6)
        Me.Controls.Add(Me.txtA7)
        Me.Controls.Add(Me.txtA9)
        Me.Controls.Add(Me.txtA1)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "frmAddMatrices3x3"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Addition 3x3"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtA1 As TextBox
    Friend WithEvents txtA9 As TextBox
    Friend WithEvents txtA7 As TextBox
    Friend WithEvents txtA6 As TextBox
    Friend WithEvents txtA5 As TextBox
    Friend WithEvents txtA4 As TextBox
    Friend WithEvents txtA3 As TextBox
    Friend WithEvents txtA2 As TextBox
    Friend WithEvents txtA8 As TextBox
    Friend WithEvents txtB8 As TextBox
    Friend WithEvents txtB2 As TextBox
    Friend WithEvents txtB3 As TextBox
    Friend WithEvents txtB4 As TextBox
    Friend WithEvents txtB5 As TextBox
    Friend WithEvents txtB6 As TextBox
    Friend WithEvents txtB7 As TextBox
    Friend WithEvents txtB9 As TextBox
    Friend WithEvents txtB1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents btnSubmit As Button
    Friend WithEvents btnHelp As Button
    Friend WithEvents txtC8 As TextBox
    Friend WithEvents txtC2 As TextBox
    Friend WithEvents txtC3 As TextBox
    Friend WithEvents txtC4 As TextBox
    Friend WithEvents txtC5 As TextBox
    Friend WithEvents txtC6 As TextBox
    Friend WithEvents txtC7 As TextBox
    Friend WithEvents txtC9 As TextBox
    Friend WithEvents txtC1 As TextBox
    Friend WithEvents btnQuit As Button
End Class
