﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCustomModeSetupAddition
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtUpperBound = New System.Windows.Forms.TextBox()
        Me.txtLowerBound = New System.Windows.Forms.TextBox()
        Me.txtQuestionsToSolve = New System.Windows.Forms.TextBox()
        Me.cmbMatrixSize = New System.Windows.Forms.ComboBox()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.btnContinue = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(53, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(346, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "How many questions would you like to solve?"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(53, 143)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(340, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Specify the ranges for elements in the array:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(53, 255)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(323, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "What size matrices would you like to add?"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(65, 195)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(95, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Lower Bound:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(233, 195)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(96, 17)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Upper Bound:"
        '
        'txtUpperBound
        '
        Me.txtUpperBound.Location = New System.Drawing.Point(336, 192)
        Me.txtUpperBound.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtUpperBound.MaxLength = 4
        Me.txtUpperBound.Name = "txtUpperBound"
        Me.txtUpperBound.Size = New System.Drawing.Size(48, 22)
        Me.txtUpperBound.TabIndex = 3
        '
        'txtLowerBound
        '
        Me.txtLowerBound.Location = New System.Drawing.Point(167, 192)
        Me.txtLowerBound.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtLowerBound.MaxLength = 4
        Me.txtLowerBound.Name = "txtLowerBound"
        Me.txtLowerBound.Size = New System.Drawing.Size(49, 22)
        Me.txtLowerBound.TabIndex = 2
        '
        'txtQuestionsToSolve
        '
        Me.txtQuestionsToSolve.Location = New System.Drawing.Point(191, 78)
        Me.txtQuestionsToSolve.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtQuestionsToSolve.MaxLength = 3
        Me.txtQuestionsToSolve.Name = "txtQuestionsToSolve"
        Me.txtQuestionsToSolve.Size = New System.Drawing.Size(68, 22)
        Me.txtQuestionsToSolve.TabIndex = 1
        '
        'cmbMatrixSize
        '
        Me.cmbMatrixSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbMatrixSize.FormattingEnabled = True
        Me.cmbMatrixSize.Items.AddRange(New Object() {"3x3", "4x4", "5x5"})
        Me.cmbMatrixSize.Location = New System.Drawing.Point(164, 290)
        Me.cmbMatrixSize.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.cmbMatrixSize.Name = "cmbMatrixSize"
        Me.cmbMatrixSize.Size = New System.Drawing.Size(121, 24)
        Me.cmbMatrixSize.TabIndex = 4
        Me.cmbMatrixSize.TabStop = False
        '
        'btnBack
        '
        Me.btnBack.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(236, 336)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(93, 42)
        Me.btnBack.TabIndex = 6
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'btnContinue
        '
        Me.btnContinue.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnContinue.Location = New System.Drawing.Point(136, 336)
        Me.btnContinue.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnContinue.Name = "btnContinue"
        Me.btnContinue.Size = New System.Drawing.Size(93, 42)
        Me.btnContinue.TabIndex = 5
        Me.btnContinue.Text = "Continue"
        Me.btnContinue.UseVisualStyleBackColor = True
        '
        'frmCustomModeSetupAddition
        '
        Me.AcceptButton = Me.btnContinue
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.CancelButton = Me.btnBack
        Me.ClientSize = New System.Drawing.Size(452, 423)
        Me.Controls.Add(Me.btnContinue)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.cmbMatrixSize)
        Me.Controls.Add(Me.txtQuestionsToSolve)
        Me.Controls.Add(Me.txtLowerBound)
        Me.Controls.Add(Me.txtUpperBound)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "frmCustomModeSetupAddition"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Custom Addition Setup"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtUpperBound As TextBox
    Friend WithEvents txtLowerBound As TextBox
    Friend WithEvents txtQuestionsToSolve As TextBox
    Friend WithEvents cmbMatrixSize As ComboBox
    Friend WithEvents btnBack As Button
    Friend WithEvents btnContinue As Button
End Class
