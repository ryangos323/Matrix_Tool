﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStoryModeExecution
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnNextQuestion = New System.Windows.Forms.Button()
        Me.prgStory = New System.Windows.Forms.ProgressBar()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tmrProgressCheck = New System.Windows.Forms.Timer(Me.components)
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtStory = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(555, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(107, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Running Story Mode:"
        '
        'btnNextQuestion
        '
        Me.btnNextQuestion.Location = New System.Drawing.Point(497, 75)
        Me.btnNextQuestion.Name = "btnNextQuestion"
        Me.btnNextQuestion.Size = New System.Drawing.Size(108, 31)
        Me.btnNextQuestion.TabIndex = 3
        Me.btnNextQuestion.Text = "Next Question"
        Me.btnNextQuestion.UseVisualStyleBackColor = True
        '
        'prgStory
        '
        Me.prgStory.BackColor = System.Drawing.Color.DarkRed
        Me.prgStory.Location = New System.Drawing.Point(13, 398)
        Me.prgStory.Name = "prgStory"
        Me.prgStory.Size = New System.Drawing.Size(1191, 23)
        Me.prgStory.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(554, 368)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(108, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Story Mode Progress:"
        '
        'tmrProgressCheck
        '
        Me.tmrProgressCheck.Enabled = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(611, 75)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(108, 31)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Save and Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'txtStory
        '
        Me.txtStory.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.5!)
        Me.txtStory.Location = New System.Drawing.Point(210, 153)
        Me.txtStory.Multiline = True
        Me.txtStory.Name = "txtStory"
        Me.txtStory.Size = New System.Drawing.Size(796, 164)
        Me.txtStory.TabIndex = 7
        Me.txtStory.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'frmStoryModeExecution
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.ClientSize = New System.Drawing.Size(1216, 433)
        Me.Controls.Add(Me.txtStory)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.prgStory)
        Me.Controls.Add(Me.btnNextQuestion)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmStoryModeExecution"
        Me.Text = "StoryModeExecution"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents btnNextQuestion As Button
    Friend WithEvents prgStory As ProgressBar
    Friend WithEvents Label2 As Label
    Friend WithEvents tmrProgressCheck As Timer
    Friend WithEvents btnExit As Button
    Friend WithEvents txtStory As TextBox
End Class
