﻿Imports System.Windows.Forms

Public Class dlgHelpSubtraction

    Private Sub btnGotIt_Click(sender As Object, e As EventArgs) Handles btnGotIt.Click
        Me.Close()
    End Sub
End Class
