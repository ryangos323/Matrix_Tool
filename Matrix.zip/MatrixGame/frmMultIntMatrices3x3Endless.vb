﻿Public Class frmMultIntMatrices3x3Endless
    Dim B1temp As Decimal
    Dim B2temp As Decimal
    Dim B3temp As Decimal
    Dim B4temp As Decimal
    Dim B5temp As Decimal
    Dim B6temp As Decimal
    Dim B7temp As Decimal
    Dim B8temp As Decimal
    Dim B9temp As Decimal

    Dim C1 As Decimal
    Dim C2 As Decimal
    Dim C3 As Decimal
    Dim C4 As Decimal
    Dim C5 As Decimal
    Dim C6 As Decimal
    Dim C7 As Decimal
    Dim C8 As Decimal
    Dim C9 As Decimal

    Dim correct As Boolean = True
    Dim i As Integer = 0
    'Checks to see if submitted answer is correct and displays corresponding message
    'Returns back to endless mode
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Try
            If B1temp.Equals(CDec(txtB1.Text)) And B2temp.Equals(CDec(txtB2.Text)) And B3temp.Equals(CDec(txtB3.Text)) And B4temp.Equals(CDec(txtB4.Text)) And B5temp.Equals(CDec(txtB5.Text)) And B6temp.Equals(CDec(txtB6.Text)) And B7temp.Equals(CDec(txtB7.Text)) And B8temp.Equals(CDec(txtB8.Text)) And B9temp.Equals(CDec(txtB9.Text)) Then
                correct = True
            Else
                correct = False
            End If

            If correct = True Then
                frmEndlessTally.correct += 1
                Dim message As String = "You got it correct."
                Dim caption As String = "Correct!"
                Dim button As MessageBoxButtons = MessageBoxButtons.OK
                Dim correctMessage As DialogResult
                correctMessage = MessageBox.Show(message, caption, button)
                i += 1
            Else
                frmEndlessTally.incorrect += 1
                Dim message As String = "You got it incorrect."
                Dim caption As String = "Incorrect!"
                Dim button As MessageBoxButtons = MessageBoxButtons.OK
                Dim incorrectMessage As DialogResult
                incorrectMessage = MessageBox.Show(message, caption, button)
                i += 1
            End If


            If i = 1 Then

                frmRunningEndless.Show()
                Me.Close()

            End If

            frmMultIntMatrices3x3Endless_Load(e, e)
            txtB1.Clear()
            txtB2.Clear()
            txtB3.Clear()
            txtB4.Clear()
            txtB5.Clear()
            txtB6.Clear()
            txtB7.Clear()
            txtB8.Clear()
            txtB9.Clear()

            txtB1.Focus()
        Catch ex As InvalidCastException
            MessageBox.Show("Please enter only numbers.", "Error")
        Catch ex As ArgumentException
            MessageBox.Show("Please enter only numbers.", "Error")
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.StackTrace)
        End Try
    End Sub

    'Generates a random matrix with specified bounds
    Private Sub frmMultIntMatrices3x3Endless_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        txtA1.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA2.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA3.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA4.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA5.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA6.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA7.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA8.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA9.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString

        B1temp = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1)
        B2temp = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1)
        B3temp = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1)
        B4temp = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1)
        B5temp = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1)
        B6temp = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1)
        B7temp = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1)
        B8temp = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1)
        B9temp = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1)

        C1 = (CDec(txtA1.Text) * B1temp) + (CDec(txtA2.Text) * B4temp) + (CDec(txtA3.Text) * B7temp)
        C2 = (CDec(txtA1.Text) * B2temp) + (CDec(txtA2.Text) * B5temp) + (CDec(txtA3.Text) * B8temp)
        C3 = (CDec(txtA1.Text) * B3temp) + (CDec(txtA2.Text) * B6temp) + (CDec(txtA3.Text) * B9temp)
        C4 = (CDec(txtA4.Text) * B1temp) + (CDec(txtA5.Text) * B4temp) + (CDec(txtA6.Text) * B7temp)
        C5 = (CDec(txtA4.Text) * B2temp) + (CDec(txtA5.Text) * B5temp) + (CDec(txtA6.Text) * B8temp)
        C6 = (CDec(txtA4.Text) * B3temp) + (CDec(txtA5.Text) * B6temp) + (CDec(txtA6.Text) * B9temp)
        C7 = (CDec(txtA7.Text) * B1temp) + (CDec(txtA8.Text) * B4temp) + (CDec(txtA9.Text) * B7temp)
        C8 = (CDec(txtA7.Text) * B2temp) + (CDec(txtA8.Text) * B5temp) + (CDec(txtA9.Text) * B8temp)
        C9 = (CDec(txtA7.Text) * B3temp) + (CDec(txtA8.Text) * B6temp) + (CDec(txtA9.Text) * B9temp)

        txtC1.Text = C1.ToString
        txtC2.Text = C2.ToString
        txtC3.Text = C3.ToString
        txtC4.Text = C4.ToString
        txtC5.Text = C5.ToString
        txtC6.Text = C6.ToString
        txtC7.Text = C7.ToString
        txtC8.Text = C8.ToString
        txtC9.Text = C9.ToString

    End Sub
    'Displays help dialog box for multiplication
    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        dlgHelpIntMultiplication.Show()

    End Sub
    'Displays ending sequence for endless mode
    Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        frmExitEndless.Show()
        Me.Close()
    End Sub
End Class