﻿Public Class frmEndlessTally
    Public Property correct As Integer
    Public Property incorrect As Integer
    'Holds values to be used by other classes
    Private Sub frmEndlessTally_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class