﻿Public Class frmAddIntMatrices3x3Endless
    Dim B1 As Decimal
    Dim B2 As Decimal
    Dim B3 As Decimal
    Dim B4 As Decimal
    Dim B5 As Decimal
    Dim B6 As Decimal
    Dim B7 As Decimal
    Dim B8 As Decimal
    Dim B9 As Decimal
    Dim correct As Boolean = True
    Dim i As Integer = 0
    'Checks the submitted values are correct to specified matrix equation
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Try
            If B1.Equals(CDec(txtB1.Text)) And B2.Equals(CDec(txtB2.Text)) And B3.Equals(CDec(txtB3.Text)) And B4.Equals(CDec(txtB4.Text)) And B5.Equals(CDec(txtB5.Text)) And B6.Equals(CDec(txtB6.Text)) And B7.Equals(CDec(txtB7.Text)) And B8.Equals(CDec(txtB8.Text)) And B9.Equals(CDec(txtB9.Text)) Then
                correct = True
            Else
                correct = False
            End If

            If correct = True Then
                frmEndlessTally.correct += 1
                Dim message As String = "You got it correct."
                Dim caption As String = "Correct!"
                Dim button As MessageBoxButtons = MessageBoxButtons.OK
                Dim correctMessage As DialogResult
                correctMessage = MessageBox.Show(message, caption, button)
                i += 1
            Else
                frmEndlessTally.incorrect += 1
                Dim message As String = "You got it incorrect."
                Dim caption As String = "Incorrect!"
                Dim button As MessageBoxButtons = MessageBoxButtons.OK
                Dim incorrectMessage As DialogResult
                incorrectMessage = MessageBox.Show(message, caption, button)
                i += 1
            End If


            If i = 1 Then

                frmRunningEndless.Show()
                Me.Close()

            End If

            frmAddIntMatrices3x3Endless_Load(e, e)
            txtB1.Clear()
            txtB2.Clear()
            txtB3.Clear()
            txtB4.Clear()
            txtB5.Clear()
            txtB6.Clear()
            txtB7.Clear()
            txtB8.Clear()
            txtB9.Clear()
            txtB1.Focus()
        Catch ex As InvalidCastException
            MessageBox.Show("Please enter only numbers.", "Error")
        Catch ex As ArgumentException
            MessageBox.Show("Please enter only numbers.", "Error")
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.StackTrace)
        End Try
    End Sub
    'Generates random matrix expression using specificed bounds
    Private Sub frmAddIntMatrices3x3Endless_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        txtA1.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA2.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA3.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA4.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA5.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA6.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA7.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA8.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA9.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString

        txtC1.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtC2.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtC3.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtC4.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtC5.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtC6.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtC7.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtC8.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtC9.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString

        B1 = (CDec(txtC1.Text) - CDec(txtA1.Text))
        B2 = (CDec(txtC2.Text) - CDec(txtA2.Text))
        B3 = (CDec(txtC3.Text) - CDec(txtA3.Text))
        B4 = (CDec(txtC4.Text) - CDec(txtA4.Text))
        B5 = (CDec(txtC5.Text) - CDec(txtA5.Text))
        B6 = (CDec(txtC6.Text) - CDec(txtA6.Text))
        B7 = (CDec(txtC7.Text) - CDec(txtA7.Text))
        B8 = (CDec(txtC8.Text) - CDec(txtA8.Text))
        B9 = (CDec(txtC9.Text) - CDec(txtA9.Text))
    End Sub
    'Displays dialog bog that shows help for the current type of problem
    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        dlgHelpIntAddition.Show()
    End Sub
    'Returns back to the custom mode setup page
    Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        frmExitEndless.Show()
        Me.Close()
    End Sub
End Class