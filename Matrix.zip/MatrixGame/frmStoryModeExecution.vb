﻿Public Class frmStoryModeExecution
    Dim correct As Boolean = False
    Public Property counter As Integer = 0
    Dim done As Boolean = False
    'Automatically disables the next question button
    Private Sub Enable(sender As Object, e As EventArgs) Handles MyBase.Shown
        btnNextQuestion.Enabled = False
        StoryModeExecution(e, e)
    End Sub
    'Calls the matrix form based on what position the user is at
    Private Sub StoryModeExecution(sender As Object, e As EventArgs) Handles btnNextQuestion.Click

        If counter = 0 Then
            frmCustomModeSetupAddition.lowerBound = 0
            frmCustomModeSetupAddition.upperBound = 9
            frmCustomModeSetupAddition.questionsToSolve = 1
            frmAddMatrices3x3.Show()
            frmAddMatrices3x3.isStory = True
            txtStory.Text = "It’s a normal day at Galloway High, but for once, you are excited.  You have a math exam today that you study very hard for.  You know you’re going to ace it! As you get off the bus, you head inside to your locker.  After putting in the combo, you open the door, and put your math notes inside for later, as the exam is not until last period.  Just as you are ready to head to home room, you feel a strong push from behind you.  You resist with all your strength, but to no avail.  You are shoved into the locker, and the door is slammed behind you.  You hear a voice from outside the locker say, 'HAHA!  Now I have you trapped.In order To escape this metal coffin, you must answer these mathematical questions.  I hope you came prepared!!!'.  The voice starts to rattle off matrix related math problems.  Press the 'Help' to look at your math notes."

        End If


        If counter = 1 Then
            frmCustomModeSetupAddition.lowerBound = 10
            frmCustomModeSetupAddition.upperBound = 20
            frmCustomModeSetupAddition.questionsToSolve = 1
            frmAddMatrices3x3.Show()
            frmAddMatrices3x3.isStory = True
            txtStory.Text = "Wow... Pretty good...NOT! These are the easy problems.  Just you wait and see!
"
        End If

        If counter = 2 Then
            frmCustomModeSetupAddition.lowerBound = 0
            frmCustomModeSetupAddition.upperBound = 9
            frmCustomModeSetupAddition.questionsToSolve = 1
            frmAddMatrices4x4.Show()
            frmAddMatrices4x4.isStory = True
            txtStory.Text = "If you think a 3x3 is hard, get ready for what’s coming."
        End If

        If counter = 3 Then
            frmCustomModeSetupAddition.lowerBound = 10
            frmCustomModeSetupAddition.upperBound = 20
            frmCustomModeSetupAddition.questionsToSolve = 1
            frmAddMatrices4x4.Show()
            frmAddMatrices4x4.isStory = True
            txtStory.Text = "4x4 DOUBLE DIGIT INCOMING!!!!"
        End If

        If counter = 4 Then
            frmCustomModeSetupAddition.lowerBound = 0
            frmCustomModeSetupAddition.upperBound = 9
            frmCustomModeSetupAddition.questionsToSolve = 1
            frmAddMatrices5x5.Show()
            frmAddMatrices5x5.isStory = True
            txtStory.Text = "Well I’ll admit, I thought I had you with that one.  Now try THIS!"
        End If

        If counter = 5 Then
            frmCustomModeSetupSubtraction.lowerBound = 0
            frmCustomModeSetupSubtraction.upperBound = 9
            frmCustomModeSetupSubtraction.questionsToSolve = 1
            frmSubMatrices3x3.Show()
            frmSubMatrices3x3.isStory = True
            txtStory.Text = "Okay, your pretty good at addition... But it’s not over yet!  Not even close"
        End If

        If counter = 6 Then
            frmCustomModeSetupSubtraction.lowerBound = 10
            frmCustomModeSetupSubtraction.upperBound = 20
            frmCustomModeSetupSubtraction.questionsToSolve = 1
            frmSubMatrices3x3.Show()
            frmSubMatrices3x3.isStory = True
            txtStory.Text = "How is subtraction treating you?  Encounter any negative numbers yet?"
        End If
        If counter = 7 Then
            frmCustomModeSetupSubtraction.lowerBound = 0
            frmCustomModeSetupSubtraction.upperBound = 10
            frmCustomModeSetupSubtraction.questionsToSolve = 1
            frmSubMatrices4x4.Show()
            frmSubMatrices4x4.isStory = True
            txtStory.Text = "I would help you out, but hearing you rattle answers through a locker door is too rich! HA!"
        End If
        If counter = 8 Then
            frmCustomModeSetupSubtraction.lowerBound = 10
            frmCustomModeSetupSubtraction.upperBound = 20
            frmCustomModeSetupSubtraction.questionsToSolve = 1
            frmSubMatrices4x4.Show()
            frmSubMatrices4x4.isStory = True
            txtStory.Text = "Subtraction 4x4 INCOMING!!! Good Luck! HAHAHA!"
        End If
        If counter = 9 Then
            frmCustomModeSetupSubtraction.lowerBound = 0
            frmCustomModeSetupSubtraction.upperBound = 10
            frmCustomModeSetupSubtraction.questionsToSolve = 1
            frmSubMatrices5x5.Show()
            frmSubMatrices5x5.isStory = True
            txtStory.Text = "Impressive...Now do this! HA! Five by Five
"
        End If
        If counter = 10 Then
            frmCustomModeSetupMultiplication.lowerBound = 0
            frmCustomModeSetupMultiplication.upperBound = 10
            frmCustomModeSetupMultiplication.questionsToSolve = 1
            frmMultMatrices2x3.Show()
            frmMultMatrices2x3.isStory = True
            txtStory.Text = "Well you did come prepared, didn’t you?  You've done subtraction and addition, but that is NOTHING compared to MULTIPICATION!"
        End If
        If counter = 11 Then
            frmCustomModeSetupMultiplication.lowerBound = 10
            frmCustomModeSetupMultiplication.upperBound = 20
            frmCustomModeSetupMultiplication.questionsToSolve = 1
            frmMultMatrices2x3.Show()
            frmMultMatrices2x3.isStory = True
            txtStory.Text = "How do you like these huh?  They don’t have to match in dimensions.  So fun isn’t it?"
        End If
        If counter = 12 Then
            frmCustomModeSetupMultiplication.lowerBound = 0
            frmCustomModeSetupMultiplication.upperBound = 10
            frmCustomModeSetupMultiplication.questionsToSolve = 1
            frmMultMatrices3x2.Show()
            frmMultMatrices3x2.isStory = True
            txtStory.Text = "It’s getting harder, isn’t it?  Well I’m not letting up yet!!!"
        End If
        If counter = 13 Then
            frmCustomModeSetupMultiplication.lowerBound = 10
            frmCustomModeSetupMultiplication.upperBound = 20
            frmCustomModeSetupMultiplication.questionsToSolve = 1
            frmMultMatrices3x2.Show()
            frmMultMatrices3x2.isStory = True
            txtStory.Text = "This is where you will fail.  I’m going to stump you!"
        End If
        If counter = 14 Then
            frmCustomModeSetupMultiplication.lowerBound = 0
            frmCustomModeSetupMultiplication.upperBound = 10
            frmCustomModeSetupMultiplication.questionsToSolve = 1
            frmMultMatrices3x3.Show()
            frmMultMatrices3x3.isStory = True
            txtStory.Text = "Hmmmm...You’re pretty good at this stuff...But what’s coming will surely ruin you!"
        End If
        If counter = 15 Then
            frmCustomModeSetupIntermediate.lowerBound = 0
            frmCustomModeSetupIntermediate.upperBound = 10
            frmCustomModeSetupIntermediate.questionsToSolve = 1
            frmAddIntMatrices3x3.Show()
            frmAddIntMatrices3x3.isStory = True
            txtStory.Text = "Wow....I can’t believe you got addition, subtraction, and multiplication...But I KNOW I’m going to stump you with these
"
        End If
        If counter = 16 Then
            frmCustomModeSetupIntermediate.lowerBound = 10
            frmCustomModeSetupIntermediate.upperBound = 20
            frmCustomModeSetupIntermediate.questionsToSolve = 1
            frmAddIntMatrices3x3.Show()
            frmAddIntMatrices3x3.isStory = True
            txtStory.Text = "Having fun yet?  I will show no mercy"
        End If
        If counter = 17 Then
            frmCustomModeSetupIntermediate.lowerBound = 0
            frmCustomModeSetupIntermediate.upperBound = 10
            frmCustomModeSetupIntermediate.questionsToSolve = 1
            frmSubIntMatrices3x3.Show()
            frmSubIntMatrices3x3.isStory = True
            txtStory.Text = "HA! I feel pity for you."
        End If
        If counter = 18 Then
            frmCustomModeSetupIntermediate.lowerBound = 10
            frmCustomModeSetupIntermediate.upperBound = 20
            frmCustomModeSetupIntermediate.questionsToSolve = 1
            frmSubIntMatrices3x3.Show()
            frmSubIntMatrices3x3.isStory = True
            txtStory.Text = "Your getting closer....Almost there"
        End If
        If counter = 19 Then
            frmCustomModeSetupIntermediate.lowerBound = 0
            frmCustomModeSetupIntermediate.upperBound = 10
            frmCustomModeSetupIntermediate.questionsToSolve = 1
            frmMultIntMatrices3x3.Show()
            frmMultIntMatrices3x3.isStory = True
            txtStory.Text = "Your freedom is right around the corner!"
            btnNextQuestion.Text = "Finish"
        End If
        btnNextQuestion.Enabled = False

        If counter = 20 Then

            btnNextQuestion.Enabled = False
            txtStory.Text = "Congratulations! You have completed the story mode of this game and successfully escaped your entrapment in your metal casket! If you wish to continue with Matrix problem, feel free to try to get a high score in our endless mode, or create your own problems to solve in our custom mode! Thank you again for playing, The Matrix Game!"
            frmMainScreen.Show()
            Me.Close()
        End If
    End Sub
    'Adjusts the progress bar constantly based on the value of counter or position
    Private Sub tmrProgressCheck_Tick(sender As Object, e As EventArgs) Handles tmrProgressCheck.Tick
        If counter <= 20 Then
            prgStory.Value = (counter) * 5
        End If
    End Sub
    'Returns back to the main menu screen and saves the progress of the current user
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        frmMainScreen.Show()
        frmStoryModeLoad.position = counter
        frmStoryModeLoad.writeFile()
        frmStoryModeLoad.Close()
        Me.Close()
    End Sub
End Class