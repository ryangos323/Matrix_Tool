﻿Public Class frmSubMatrices5x5Endless
    Dim C1 As Decimal
    Dim C2 As Decimal
    Dim C3 As Decimal
    Dim C4 As Decimal
    Dim C5 As Decimal
    Dim C6 As Decimal
    Dim C7 As Decimal
    Dim C8 As Decimal
    Dim C9 As Decimal
    Dim C10 As Decimal
    Dim C11 As Decimal
    Dim C12 As Decimal
    Dim C13 As Decimal
    Dim C14 As Decimal
    Dim C15 As Decimal
    Dim C16 As Decimal
    Dim C17 As Decimal
    Dim C18 As Decimal
    Dim C19 As Decimal
    Dim C20 As Decimal
    Dim C21 As Decimal
    Dim C22 As Decimal
    Dim C23 As Decimal
    Dim C24 As Decimal
    Dim C25 As Decimal

    Dim correct As Boolean = True
    Dim i As Integer = 0
    'Takes the text values of the answer text box and checks against correct answer
    'Outputs correct or incorrect message and returns back to endless form
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Try
            If C1.Equals(CDec(txtC1.Text)) And C2.Equals(CDec(txtC2.Text)) And C3.Equals(CDec(txtC3.Text)) And C4.Equals(CDec(txtC4.Text)) And C5.Equals(CDec(txtC5.Text)) And C6.Equals(CDec(txtC6.Text)) And C7.Equals(CDec(txtC7.Text)) And C8.Equals(CDec(txtC8.Text)) And C9.Equals(CDec(txtC9.Text)) And C10.Equals(CDec(txtC10.Text)) And C11.Equals(CDec(txtC11.Text)) And C12.Equals(CDec(txtC12.Text)) And C13.Equals(CDec(txtC13.Text)) And C14.Equals(CDec(txtC14.Text)) And C15.Equals(CDec(txtC15.Text)) And C16.Equals(CDec(txtC16.Text)) And C17.Equals(CDec(txtC17.Text)) And C18.Equals(CDec(txtC18.Text)) And C19.Equals(CDec(txtC19.Text)) And C20.Equals(CDec(txtC20.Text)) And C21.Equals(CDec(txtC21.Text)) And C22.Equals(CDec(txtC22.Text)) And C23.Equals(CDec(txtC23.Text)) And C24.Equals(CDec(txtC24.Text)) And C25.Equals(CDec(txtC25.Text)) Then
                correct = True
            Else
                correct = False
            End If

            If correct = True Then
                frmEndlessTally.correct += 1
                Dim message As String = "You got it correct."
                Dim caption As String = "Correct!"
                Dim button As MessageBoxButtons = MessageBoxButtons.OK
                Dim correctMessage As DialogResult
                correctMessage = MessageBox.Show(message, caption, button)
                i += 1
            Else
                frmEndlessTally.incorrect += 1
                Dim message As String = "You got it incorrect."
                Dim caption As String = "Incorrect!"
                Dim button As MessageBoxButtons = MessageBoxButtons.OK
                Dim incorrectMessage As DialogResult
                incorrectMessage = MessageBox.Show(message, caption, button)
                i += 1
            End If


            If i = 1 Then

                frmRunningEndless.Show()
                Me.Close()

            End If

            frmSubMatrices5x5Endless_Load(e, e)
            txtC1.Clear()
            txtC2.Clear()
            txtC3.Clear()
            txtC4.Clear()
            txtC5.Clear()
            txtC6.Clear()
            txtC7.Clear()
            txtC8.Clear()
            txtC9.Clear()
            txtC10.Clear()
            txtC11.Clear()
            txtC12.Clear()
            txtC13.Clear()
            txtC14.Clear()
            txtC15.Clear()
            txtC16.Clear()
            txtC17.Clear()
            txtC18.Clear()
            txtC19.Clear()
            txtC20.Clear()
            txtC21.Clear()
            txtC22.Clear()
            txtC23.Clear()
            txtC24.Clear()
            txtC25.Clear()
            txtC1.Focus()
        Catch ex As InvalidCastException
            MessageBox.Show("Please enter only numbers.", "Error")
        Catch ex As ArgumentException
            MessageBox.Show("Please enter only numbers.", "Error")
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.StackTrace)
        End Try
    End Sub
    'Loads the matrices with random integers and creates the problem
    Private Sub frmSubMatrices5x5Endless_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        txtA1.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA2.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA3.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA4.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA5.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA6.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA7.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA8.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA9.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA10.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA11.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA12.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA13.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA14.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA15.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA16.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA17.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA18.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA19.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA20.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA21.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA22.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA23.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA24.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA25.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString

        txtB1.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB2.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB3.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB4.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB5.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB6.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB7.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB8.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB9.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB10.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB11.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB12.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB13.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB14.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB15.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB16.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB17.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB18.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB19.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB20.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB21.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB22.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB23.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB24.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB25.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString

        C1 = (CDec(txtA1.Text) - CDec(txtB1.Text))
        C2 = (CDec(txtA2.Text) - CDec(txtB2.Text))
        C3 = (CDec(txtA3.Text) - CDec(txtB3.Text))
        C4 = (CDec(txtA4.Text) - CDec(txtB4.Text))
        C5 = (CDec(txtA5.Text) - CDec(txtB5.Text))
        C6 = (CDec(txtA6.Text) - CDec(txtB6.Text))
        C7 = (CDec(txtA7.Text) - CDec(txtB7.Text))
        C8 = (CDec(txtA8.Text) - CDec(txtB8.Text))
        C9 = (CDec(txtA9.Text) - CDec(txtB9.Text))
        C10 = (CDec(txtA10.Text) - CDec(txtB10.Text))
        C11 = (CDec(txtA11.Text) - CDec(txtB11.Text))
        C12 = (CDec(txtA12.Text) - CDec(txtB12.Text))
        C13 = (CDec(txtA13.Text) - CDec(txtB13.Text))
        C14 = (CDec(txtA14.Text) - CDec(txtB14.Text))
        C15 = (CDec(txtA15.Text) - CDec(txtB15.Text))
        C16 = (CDec(txtA16.Text) - CDec(txtB16.Text))
        C17 = (CDec(txtA17.Text) - CDec(txtB17.Text))
        C18 = (CDec(txtA18.Text) - CDec(txtB18.Text))
        C19 = (CDec(txtA19.Text) - CDec(txtB19.Text))
        C20 = (CDec(txtA20.Text) - CDec(txtB20.Text))
        C21 = (CDec(txtA21.Text) - CDec(txtB21.Text))
        C22 = (CDec(txtA22.Text) - CDec(txtB22.Text))
        C23 = (CDec(txtA23.Text) - CDec(txtB23.Text))
        C24 = (CDec(txtA24.Text) - CDec(txtB24.Text))
        C25 = (CDec(txtA25.Text) - CInt(txtB25.Text))
    End Sub
    'Displays the ending form for endless mode
    Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        frmExitEndless.Show()
        Me.Close()
    End Sub
    'Displays help dialog box
    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        dlgHelpSubtraction.Show()
    End Sub
End Class