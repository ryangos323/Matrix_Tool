﻿Public Class frmStoryModeSelect
    'Returns back to the level selection screen if the back button is clicked
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        frmLevelSelection.Show()
        Me.Close()
    End Sub
    'Launches the new save form when the new button is clicked
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        frmStoryModeNew.Show()
        Me.Close()
    End Sub
    'Launcehs the load form when the load button is clicked
    Private Sub btnLoad_Click(sender As Object, e As EventArgs) Handles btnLoad.Click
        frmStoryModeLoad.Show()
        Me.Close()
    End Sub
End Class