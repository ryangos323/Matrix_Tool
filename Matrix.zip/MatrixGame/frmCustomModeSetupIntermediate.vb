﻿Public Class frmCustomModeSetupIntermediate
    Public Property questionsToSolve As Integer
    Public Property lowerBound As Integer
    Public Property upperBound As Integer

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        frmCustomModeSetup.Show()
        Me.Close()
    End Sub
    'Sets the specified values the user wishes to user in custom mode
    Private Sub btnContinue_Click(sender As Object, e As EventArgs) Handles btnContinue.Click
        Try
            questionsToSolve = CInt(txtQuestionsToSolve.Text)
            lowerBound = CInt(txtLowerBound.Text)
            upperBound = CInt(txtUpperBound.Text)

            If cmbMatrixSize.SelectedIndex = 0 Then
                frmAddIntMatrices3x3.Show()
                Me.Close()
            ElseIf cmbMatrixSize.SelectedIndex = 1 Then
                frmSubIntMatrices3x3.Show()
                Me.Close()
            ElseIf cmbMatrixSize.SelectedIndex = 2 Then
                frmMultIntMatrices3x3.Show()
                Me.Close()
            ElseIf cmbMatrixSize.SelectedIndex = -1 Then
                MessageBox.Show("Select a matrix size from the dropdown list.", "Error")

            End If
        Catch ex As InvalidCastException
            MessageBox.Show("Please enter only numbers.", "Error")
        Catch ex As ArgumentException
            MessageBox.Show("Please enter only numbers.", "Error")
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.StackTrace)
        End Try
    End Sub

End Class