﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSubMatrices4x4Endless
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtC16 = New System.Windows.Forms.TextBox()
        Me.txtC13 = New System.Windows.Forms.TextBox()
        Me.txtC14 = New System.Windows.Forms.TextBox()
        Me.txtC15 = New System.Windows.Forms.TextBox()
        Me.txtC4 = New System.Windows.Forms.TextBox()
        Me.txtC8 = New System.Windows.Forms.TextBox()
        Me.txtC12 = New System.Windows.Forms.TextBox()
        Me.txtA13 = New System.Windows.Forms.TextBox()
        Me.txtA14 = New System.Windows.Forms.TextBox()
        Me.txtA15 = New System.Windows.Forms.TextBox()
        Me.txtA16 = New System.Windows.Forms.TextBox()
        Me.txtA12 = New System.Windows.Forms.TextBox()
        Me.txtA8 = New System.Windows.Forms.TextBox()
        Me.txtA4 = New System.Windows.Forms.TextBox()
        Me.txtB14 = New System.Windows.Forms.TextBox()
        Me.txtB13 = New System.Windows.Forms.TextBox()
        Me.txtB8 = New System.Windows.Forms.TextBox()
        Me.txtB4 = New System.Windows.Forms.TextBox()
        Me.txtB16 = New System.Windows.Forms.TextBox()
        Me.txtB15 = New System.Windows.Forms.TextBox()
        Me.txtB12 = New System.Windows.Forms.TextBox()
        Me.txtC10 = New System.Windows.Forms.TextBox()
        Me.txtC2 = New System.Windows.Forms.TextBox()
        Me.txtC3 = New System.Windows.Forms.TextBox()
        Me.txtC5 = New System.Windows.Forms.TextBox()
        Me.txtC6 = New System.Windows.Forms.TextBox()
        Me.txtC7 = New System.Windows.Forms.TextBox()
        Me.txtC9 = New System.Windows.Forms.TextBox()
        Me.txtC11 = New System.Windows.Forms.TextBox()
        Me.txtC1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtB10 = New System.Windows.Forms.TextBox()
        Me.txtB2 = New System.Windows.Forms.TextBox()
        Me.txtB3 = New System.Windows.Forms.TextBox()
        Me.txtB5 = New System.Windows.Forms.TextBox()
        Me.txtB6 = New System.Windows.Forms.TextBox()
        Me.txtB7 = New System.Windows.Forms.TextBox()
        Me.txtB9 = New System.Windows.Forms.TextBox()
        Me.txtB11 = New System.Windows.Forms.TextBox()
        Me.txtB1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtA10 = New System.Windows.Forms.TextBox()
        Me.txtA2 = New System.Windows.Forms.TextBox()
        Me.txtA3 = New System.Windows.Forms.TextBox()
        Me.txtA5 = New System.Windows.Forms.TextBox()
        Me.txtA6 = New System.Windows.Forms.TextBox()
        Me.txtA7 = New System.Windows.Forms.TextBox()
        Me.txtA9 = New System.Windows.Forms.TextBox()
        Me.txtA11 = New System.Windows.Forms.TextBox()
        Me.txtA1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnHelp = New System.Windows.Forms.Button()
        Me.btnQuit = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtC16
        '
        Me.txtC16.Location = New System.Drawing.Point(832, 132)
        Me.txtC16.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC16.Name = "txtC16"
        Me.txtC16.Size = New System.Drawing.Size(56, 20)
        Me.txtC16.TabIndex = 16
        '
        'txtC13
        '
        Me.txtC13.Location = New System.Drawing.Point(653, 132)
        Me.txtC13.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC13.Name = "txtC13"
        Me.txtC13.Size = New System.Drawing.Size(56, 20)
        Me.txtC13.TabIndex = 13
        '
        'txtC14
        '
        Me.txtC14.Location = New System.Drawing.Point(713, 132)
        Me.txtC14.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC14.Name = "txtC14"
        Me.txtC14.Size = New System.Drawing.Size(56, 20)
        Me.txtC14.TabIndex = 14
        '
        'txtC15
        '
        Me.txtC15.Location = New System.Drawing.Point(773, 132)
        Me.txtC15.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC15.Name = "txtC15"
        Me.txtC15.Size = New System.Drawing.Size(56, 20)
        Me.txtC15.TabIndex = 15
        '
        'txtC4
        '
        Me.txtC4.Location = New System.Drawing.Point(832, 66)
        Me.txtC4.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC4.Name = "txtC4"
        Me.txtC4.Size = New System.Drawing.Size(56, 20)
        Me.txtC4.TabIndex = 4
        '
        'txtC8
        '
        Me.txtC8.Location = New System.Drawing.Point(832, 88)
        Me.txtC8.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC8.Name = "txtC8"
        Me.txtC8.Size = New System.Drawing.Size(56, 20)
        Me.txtC8.TabIndex = 8
        '
        'txtC12
        '
        Me.txtC12.Location = New System.Drawing.Point(832, 110)
        Me.txtC12.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC12.Name = "txtC12"
        Me.txtC12.Size = New System.Drawing.Size(56, 20)
        Me.txtC12.TabIndex = 12
        '
        'txtA13
        '
        Me.txtA13.Location = New System.Drawing.Point(36, 132)
        Me.txtA13.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA13.Name = "txtA13"
        Me.txtA13.ReadOnly = True
        Me.txtA13.Size = New System.Drawing.Size(56, 20)
        Me.txtA13.TabIndex = 136
        Me.txtA13.TabStop = False
        '
        'txtA14
        '
        Me.txtA14.Location = New System.Drawing.Point(96, 132)
        Me.txtA14.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA14.Name = "txtA14"
        Me.txtA14.ReadOnly = True
        Me.txtA14.Size = New System.Drawing.Size(56, 20)
        Me.txtA14.TabIndex = 135
        Me.txtA14.TabStop = False
        '
        'txtA15
        '
        Me.txtA15.Location = New System.Drawing.Point(156, 132)
        Me.txtA15.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA15.Name = "txtA15"
        Me.txtA15.ReadOnly = True
        Me.txtA15.Size = New System.Drawing.Size(56, 20)
        Me.txtA15.TabIndex = 134
        Me.txtA15.TabStop = False
        '
        'txtA16
        '
        Me.txtA16.Location = New System.Drawing.Point(215, 132)
        Me.txtA16.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA16.Name = "txtA16"
        Me.txtA16.ReadOnly = True
        Me.txtA16.Size = New System.Drawing.Size(56, 20)
        Me.txtA16.TabIndex = 133
        Me.txtA16.TabStop = False
        '
        'txtA12
        '
        Me.txtA12.Location = New System.Drawing.Point(215, 110)
        Me.txtA12.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA12.Name = "txtA12"
        Me.txtA12.ReadOnly = True
        Me.txtA12.Size = New System.Drawing.Size(56, 20)
        Me.txtA12.TabIndex = 132
        Me.txtA12.TabStop = False
        '
        'txtA8
        '
        Me.txtA8.Location = New System.Drawing.Point(215, 88)
        Me.txtA8.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA8.Name = "txtA8"
        Me.txtA8.ReadOnly = True
        Me.txtA8.Size = New System.Drawing.Size(56, 20)
        Me.txtA8.TabIndex = 131
        Me.txtA8.TabStop = False
        '
        'txtA4
        '
        Me.txtA4.Location = New System.Drawing.Point(215, 66)
        Me.txtA4.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA4.Name = "txtA4"
        Me.txtA4.ReadOnly = True
        Me.txtA4.Size = New System.Drawing.Size(56, 20)
        Me.txtA4.TabIndex = 130
        Me.txtA4.TabStop = False
        '
        'txtB14
        '
        Me.txtB14.Location = New System.Drawing.Point(410, 132)
        Me.txtB14.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB14.Name = "txtB14"
        Me.txtB14.ReadOnly = True
        Me.txtB14.Size = New System.Drawing.Size(56, 20)
        Me.txtB14.TabIndex = 129
        Me.txtB14.TabStop = False
        '
        'txtB13
        '
        Me.txtB13.Location = New System.Drawing.Point(351, 132)
        Me.txtB13.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB13.Name = "txtB13"
        Me.txtB13.ReadOnly = True
        Me.txtB13.Size = New System.Drawing.Size(56, 20)
        Me.txtB13.TabIndex = 128
        Me.txtB13.TabStop = False
        '
        'txtB8
        '
        Me.txtB8.Location = New System.Drawing.Point(530, 88)
        Me.txtB8.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB8.Name = "txtB8"
        Me.txtB8.ReadOnly = True
        Me.txtB8.Size = New System.Drawing.Size(56, 20)
        Me.txtB8.TabIndex = 127
        Me.txtB8.TabStop = False
        '
        'txtB4
        '
        Me.txtB4.Location = New System.Drawing.Point(530, 66)
        Me.txtB4.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB4.Name = "txtB4"
        Me.txtB4.ReadOnly = True
        Me.txtB4.Size = New System.Drawing.Size(56, 20)
        Me.txtB4.TabIndex = 126
        Me.txtB4.TabStop = False
        '
        'txtB16
        '
        Me.txtB16.Location = New System.Drawing.Point(530, 132)
        Me.txtB16.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB16.Name = "txtB16"
        Me.txtB16.ReadOnly = True
        Me.txtB16.Size = New System.Drawing.Size(56, 20)
        Me.txtB16.TabIndex = 125
        Me.txtB16.TabStop = False
        '
        'txtB15
        '
        Me.txtB15.Location = New System.Drawing.Point(470, 132)
        Me.txtB15.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB15.Name = "txtB15"
        Me.txtB15.ReadOnly = True
        Me.txtB15.Size = New System.Drawing.Size(56, 20)
        Me.txtB15.TabIndex = 124
        Me.txtB15.TabStop = False
        '
        'txtB12
        '
        Me.txtB12.Location = New System.Drawing.Point(530, 110)
        Me.txtB12.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB12.Name = "txtB12"
        Me.txtB12.ReadOnly = True
        Me.txtB12.Size = New System.Drawing.Size(56, 20)
        Me.txtB12.TabIndex = 123
        Me.txtB12.TabStop = False
        '
        'txtC10
        '
        Me.txtC10.Location = New System.Drawing.Point(713, 110)
        Me.txtC10.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC10.Name = "txtC10"
        Me.txtC10.Size = New System.Drawing.Size(56, 20)
        Me.txtC10.TabIndex = 10
        '
        'txtC2
        '
        Me.txtC2.Location = New System.Drawing.Point(713, 66)
        Me.txtC2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC2.Name = "txtC2"
        Me.txtC2.Size = New System.Drawing.Size(56, 20)
        Me.txtC2.TabIndex = 2
        '
        'txtC3
        '
        Me.txtC3.Location = New System.Drawing.Point(773, 66)
        Me.txtC3.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC3.Name = "txtC3"
        Me.txtC3.Size = New System.Drawing.Size(56, 20)
        Me.txtC3.TabIndex = 3
        '
        'txtC5
        '
        Me.txtC5.Location = New System.Drawing.Point(653, 88)
        Me.txtC5.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC5.Name = "txtC5"
        Me.txtC5.Size = New System.Drawing.Size(56, 20)
        Me.txtC5.TabIndex = 5
        '
        'txtC6
        '
        Me.txtC6.Location = New System.Drawing.Point(713, 88)
        Me.txtC6.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC6.Name = "txtC6"
        Me.txtC6.Size = New System.Drawing.Size(56, 20)
        Me.txtC6.TabIndex = 6
        '
        'txtC7
        '
        Me.txtC7.Location = New System.Drawing.Point(773, 88)
        Me.txtC7.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC7.Name = "txtC7"
        Me.txtC7.Size = New System.Drawing.Size(56, 20)
        Me.txtC7.TabIndex = 7
        '
        'txtC9
        '
        Me.txtC9.Location = New System.Drawing.Point(653, 110)
        Me.txtC9.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC9.Name = "txtC9"
        Me.txtC9.Size = New System.Drawing.Size(56, 20)
        Me.txtC9.TabIndex = 9
        '
        'txtC11
        '
        Me.txtC11.Location = New System.Drawing.Point(773, 110)
        Me.txtC11.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC11.Name = "txtC11"
        Me.txtC11.Size = New System.Drawing.Size(56, 20)
        Me.txtC11.TabIndex = 11
        '
        'txtC1
        '
        Me.txtC1.Location = New System.Drawing.Point(653, 66)
        Me.txtC1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC1.Name = "txtC1"
        Me.txtC1.Size = New System.Drawing.Size(56, 20)
        Me.txtC1.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(651, 29)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(136, 20)
        Me.Label5.TabIndex = 111
        Me.Label5.Text = "Solve for Matrix C:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(608, 88)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(30, 31)
        Me.Label4.TabIndex = 110
        Me.Label4.Text = "="
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(297, 88)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(23, 31)
        Me.Label3.TabIndex = 109
        Me.Label3.Text = "-"
        '
        'txtB10
        '
        Me.txtB10.Location = New System.Drawing.Point(410, 110)
        Me.txtB10.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB10.Name = "txtB10"
        Me.txtB10.ReadOnly = True
        Me.txtB10.Size = New System.Drawing.Size(56, 20)
        Me.txtB10.TabIndex = 108
        Me.txtB10.TabStop = False
        '
        'txtB2
        '
        Me.txtB2.Location = New System.Drawing.Point(410, 66)
        Me.txtB2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB2.Name = "txtB2"
        Me.txtB2.ReadOnly = True
        Me.txtB2.Size = New System.Drawing.Size(56, 20)
        Me.txtB2.TabIndex = 107
        Me.txtB2.TabStop = False
        '
        'txtB3
        '
        Me.txtB3.Location = New System.Drawing.Point(470, 66)
        Me.txtB3.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB3.Name = "txtB3"
        Me.txtB3.ReadOnly = True
        Me.txtB3.Size = New System.Drawing.Size(56, 20)
        Me.txtB3.TabIndex = 106
        Me.txtB3.TabStop = False
        '
        'txtB5
        '
        Me.txtB5.Location = New System.Drawing.Point(350, 88)
        Me.txtB5.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB5.Name = "txtB5"
        Me.txtB5.ReadOnly = True
        Me.txtB5.Size = New System.Drawing.Size(56, 20)
        Me.txtB5.TabIndex = 105
        Me.txtB5.TabStop = False
        '
        'txtB6
        '
        Me.txtB6.Location = New System.Drawing.Point(410, 88)
        Me.txtB6.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB6.Name = "txtB6"
        Me.txtB6.ReadOnly = True
        Me.txtB6.Size = New System.Drawing.Size(56, 20)
        Me.txtB6.TabIndex = 104
        Me.txtB6.TabStop = False
        '
        'txtB7
        '
        Me.txtB7.Location = New System.Drawing.Point(470, 88)
        Me.txtB7.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB7.Name = "txtB7"
        Me.txtB7.ReadOnly = True
        Me.txtB7.Size = New System.Drawing.Size(56, 20)
        Me.txtB7.TabIndex = 103
        Me.txtB7.TabStop = False
        '
        'txtB9
        '
        Me.txtB9.Location = New System.Drawing.Point(350, 110)
        Me.txtB9.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB9.Name = "txtB9"
        Me.txtB9.ReadOnly = True
        Me.txtB9.Size = New System.Drawing.Size(56, 20)
        Me.txtB9.TabIndex = 102
        Me.txtB9.TabStop = False
        '
        'txtB11
        '
        Me.txtB11.Location = New System.Drawing.Point(470, 110)
        Me.txtB11.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB11.Name = "txtB11"
        Me.txtB11.ReadOnly = True
        Me.txtB11.Size = New System.Drawing.Size(56, 20)
        Me.txtB11.TabIndex = 101
        Me.txtB11.TabStop = False
        '
        'txtB1
        '
        Me.txtB1.Location = New System.Drawing.Point(350, 66)
        Me.txtB1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB1.Name = "txtB1"
        Me.txtB1.ReadOnly = True
        Me.txtB1.Size = New System.Drawing.Size(56, 20)
        Me.txtB1.TabIndex = 100
        Me.txtB1.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(347, 29)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 20)
        Me.Label2.TabIndex = 99
        Me.Label2.Text = "Matrix B:"
        '
        'txtA10
        '
        Me.txtA10.Location = New System.Drawing.Point(96, 110)
        Me.txtA10.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA10.Name = "txtA10"
        Me.txtA10.ReadOnly = True
        Me.txtA10.Size = New System.Drawing.Size(56, 20)
        Me.txtA10.TabIndex = 98
        Me.txtA10.TabStop = False
        '
        'txtA2
        '
        Me.txtA2.Location = New System.Drawing.Point(96, 66)
        Me.txtA2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA2.Name = "txtA2"
        Me.txtA2.ReadOnly = True
        Me.txtA2.Size = New System.Drawing.Size(56, 20)
        Me.txtA2.TabIndex = 97
        Me.txtA2.TabStop = False
        '
        'txtA3
        '
        Me.txtA3.Location = New System.Drawing.Point(156, 66)
        Me.txtA3.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA3.Name = "txtA3"
        Me.txtA3.ReadOnly = True
        Me.txtA3.Size = New System.Drawing.Size(56, 20)
        Me.txtA3.TabIndex = 96
        Me.txtA3.TabStop = False
        '
        'txtA5
        '
        Me.txtA5.Location = New System.Drawing.Point(36, 88)
        Me.txtA5.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA5.Name = "txtA5"
        Me.txtA5.ReadOnly = True
        Me.txtA5.Size = New System.Drawing.Size(56, 20)
        Me.txtA5.TabIndex = 95
        Me.txtA5.TabStop = False
        '
        'txtA6
        '
        Me.txtA6.Location = New System.Drawing.Point(96, 88)
        Me.txtA6.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA6.Name = "txtA6"
        Me.txtA6.ReadOnly = True
        Me.txtA6.Size = New System.Drawing.Size(56, 20)
        Me.txtA6.TabIndex = 94
        Me.txtA6.TabStop = False
        '
        'txtA7
        '
        Me.txtA7.Location = New System.Drawing.Point(156, 88)
        Me.txtA7.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA7.Name = "txtA7"
        Me.txtA7.ReadOnly = True
        Me.txtA7.Size = New System.Drawing.Size(56, 20)
        Me.txtA7.TabIndex = 93
        Me.txtA7.TabStop = False
        '
        'txtA9
        '
        Me.txtA9.Location = New System.Drawing.Point(36, 110)
        Me.txtA9.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA9.Name = "txtA9"
        Me.txtA9.ReadOnly = True
        Me.txtA9.Size = New System.Drawing.Size(56, 20)
        Me.txtA9.TabIndex = 92
        Me.txtA9.TabStop = False
        '
        'txtA11
        '
        Me.txtA11.Location = New System.Drawing.Point(156, 110)
        Me.txtA11.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA11.Name = "txtA11"
        Me.txtA11.ReadOnly = True
        Me.txtA11.Size = New System.Drawing.Size(56, 20)
        Me.txtA11.TabIndex = 91
        Me.txtA11.TabStop = False
        '
        'txtA1
        '
        Me.txtA1.Location = New System.Drawing.Point(36, 66)
        Me.txtA1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA1.Name = "txtA1"
        Me.txtA1.ReadOnly = True
        Me.txtA1.Size = New System.Drawing.Size(56, 20)
        Me.txtA1.TabIndex = 90
        Me.txtA1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(34, 29)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(70, 20)
        Me.Label1.TabIndex = 89
        Me.Label1.Text = "Matrix A:"
        '
        'btnHelp
        '
        Me.btnHelp.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHelp.Location = New System.Drawing.Point(424, 167)
        Me.btnHelp.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(77, 40)
        Me.btnHelp.TabIndex = 18
        Me.btnHelp.Text = "Help"
        Me.btnHelp.UseVisualStyleBackColor = True
        '
        'btnQuit
        '
        Me.btnQuit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnQuit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuit.Location = New System.Drawing.Point(521, 167)
        Me.btnQuit.Margin = New System.Windows.Forms.Padding(2)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(77, 40)
        Me.btnQuit.TabIndex = 19
        Me.btnQuit.Text = "Quit"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(328, 167)
        Me.btnSubmit.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(77, 40)
        Me.btnSubmit.TabIndex = 17
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'frmSubMatrices4x4Endless
        '
        Me.AcceptButton = Me.btnSubmit
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.CancelButton = Me.btnQuit
        Me.ClientSize = New System.Drawing.Size(921, 228)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.btnHelp)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.txtC16)
        Me.Controls.Add(Me.txtC13)
        Me.Controls.Add(Me.txtC14)
        Me.Controls.Add(Me.txtC15)
        Me.Controls.Add(Me.txtC4)
        Me.Controls.Add(Me.txtC8)
        Me.Controls.Add(Me.txtC12)
        Me.Controls.Add(Me.txtA13)
        Me.Controls.Add(Me.txtA14)
        Me.Controls.Add(Me.txtA15)
        Me.Controls.Add(Me.txtA16)
        Me.Controls.Add(Me.txtA12)
        Me.Controls.Add(Me.txtA8)
        Me.Controls.Add(Me.txtA4)
        Me.Controls.Add(Me.txtB14)
        Me.Controls.Add(Me.txtB13)
        Me.Controls.Add(Me.txtB8)
        Me.Controls.Add(Me.txtB4)
        Me.Controls.Add(Me.txtB16)
        Me.Controls.Add(Me.txtB15)
        Me.Controls.Add(Me.txtB12)
        Me.Controls.Add(Me.txtC10)
        Me.Controls.Add(Me.txtC2)
        Me.Controls.Add(Me.txtC3)
        Me.Controls.Add(Me.txtC5)
        Me.Controls.Add(Me.txtC6)
        Me.Controls.Add(Me.txtC7)
        Me.Controls.Add(Me.txtC9)
        Me.Controls.Add(Me.txtC11)
        Me.Controls.Add(Me.txtC1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtB10)
        Me.Controls.Add(Me.txtB2)
        Me.Controls.Add(Me.txtB3)
        Me.Controls.Add(Me.txtB5)
        Me.Controls.Add(Me.txtB6)
        Me.Controls.Add(Me.txtB7)
        Me.Controls.Add(Me.txtB9)
        Me.Controls.Add(Me.txtB11)
        Me.Controls.Add(Me.txtB1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtA10)
        Me.Controls.Add(Me.txtA2)
        Me.Controls.Add(Me.txtA3)
        Me.Controls.Add(Me.txtA5)
        Me.Controls.Add(Me.txtA6)
        Me.Controls.Add(Me.txtA7)
        Me.Controls.Add(Me.txtA9)
        Me.Controls.Add(Me.txtA11)
        Me.Controls.Add(Me.txtA1)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "frmSubMatrices4x4Endless"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Subtraction 4x4"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtC16 As TextBox
    Friend WithEvents txtC13 As TextBox
    Friend WithEvents txtC14 As TextBox
    Friend WithEvents txtC15 As TextBox
    Friend WithEvents txtC4 As TextBox
    Friend WithEvents txtC8 As TextBox
    Friend WithEvents txtC12 As TextBox
    Friend WithEvents txtA13 As TextBox
    Friend WithEvents txtA14 As TextBox
    Friend WithEvents txtA15 As TextBox
    Friend WithEvents txtA16 As TextBox
    Friend WithEvents txtA12 As TextBox
    Friend WithEvents txtA8 As TextBox
    Friend WithEvents txtA4 As TextBox
    Friend WithEvents txtB14 As TextBox
    Friend WithEvents txtB13 As TextBox
    Friend WithEvents txtB8 As TextBox
    Friend WithEvents txtB4 As TextBox
    Friend WithEvents txtB16 As TextBox
    Friend WithEvents txtB15 As TextBox
    Friend WithEvents txtB12 As TextBox
    Friend WithEvents txtC10 As TextBox
    Friend WithEvents txtC2 As TextBox
    Friend WithEvents txtC3 As TextBox
    Friend WithEvents txtC5 As TextBox
    Friend WithEvents txtC6 As TextBox
    Friend WithEvents txtC7 As TextBox
    Friend WithEvents txtC9 As TextBox
    Friend WithEvents txtC11 As TextBox
    Friend WithEvents txtC1 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtB10 As TextBox
    Friend WithEvents txtB2 As TextBox
    Friend WithEvents txtB3 As TextBox
    Friend WithEvents txtB5 As TextBox
    Friend WithEvents txtB6 As TextBox
    Friend WithEvents txtB7 As TextBox
    Friend WithEvents txtB9 As TextBox
    Friend WithEvents txtB11 As TextBox
    Friend WithEvents txtB1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtA10 As TextBox
    Friend WithEvents txtA2 As TextBox
    Friend WithEvents txtA3 As TextBox
    Friend WithEvents txtA5 As TextBox
    Friend WithEvents txtA6 As TextBox
    Friend WithEvents txtA7 As TextBox
    Friend WithEvents txtA9 As TextBox
    Friend WithEvents txtA11 As TextBox
    Friend WithEvents txtA1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnHelp As Button
    Friend WithEvents btnQuit As Button
    Friend WithEvents btnSubmit As Button
End Class
