﻿Imports System.IO
Imports System.IO.File
Public Class frmExitEndless
    Dim ratio As Decimal
    'Stores the values of correct and incorrect to be used
    Private Sub frmExitEndless_Load(sender As Object, e As EventArgs) Handles MyBase.Load, MyBase.Shown

        If (frmEndlessTally.correct = 0 And frmEndlessTally.incorrect = 0) Then
            frmLevelSelection.Show()
            Me.Close()
        Else
            ratio = 0D
            lblCorrect.Text = frmEndlessTally.correct.ToString
            lblIncorrect.Text = frmEndlessTally.incorrect.ToString
            ratio = CDec(frmEndlessTally.correct / (frmEndlessTally.correct + frmEndlessTally.incorrect))
            lblRatio.Text = ratio.ToString("p")
        End If
    End Sub
    'Saves scores including new score to high scores text file
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim fileThing As System.IO.StreamWriter
        Dim path As String = My.Application.Info.DirectoryPath
        Dim path2 As String = IO.Path.Combine(path, "HighScores.txt")
        fileThing = My.Computer.FileSystem.OpenTextFileWriter(path2, True)
        Dim playerData As String = ratio.ToString("p") & " - Win/Loss Ratio | | Name: " & txtName.Text & " | Correct: " & frmEndlessTally.correct.ToString & " | Incorrect: " & frmEndlessTally.incorrect.ToString
        fileThing.WriteLine(playerData)
        fileThing.Close()
        'Dim reader As New StreamReader("HighScores.txt")
        'Dim countLines As String = "notNothing"
        Dim numLines As Integer = File.ReadAllLines("HighScores.txt").Length
        'Do
        'countLines = reader.ReadLine()
        'numLines += 1
        'Loop Until countLines Is Nothing
        'reader.Close()
        numLines -= 1
        Dim scores(numLines) As String
        Dim reader2 As New StreamReader("HighScores.txt")
        If numLines < 5 Then
            For q As Integer = 0 To numLines
                scores(q) = reader2.ReadLine()
            Next q
        Else
            For q As Integer = 0 To 5
                scores(q) = reader2.ReadLine()
            Next q
        End If
        reader2.Close()
        Array.Sort(scores)
        My.Computer.FileSystem.DeleteFile("HighScores.txt")
        Dim file2 As System.IO.StreamWriter
        Dim path3 As String = My.Application.Info.DirectoryPath
        Dim path4 As String = IO.Path.Combine(path3, "HighScores.txt")
        file2 = My.Computer.FileSystem.OpenTextFileWriter(path2, True)
        For q As Integer = (scores.Length - 1) To 0 Step -1
            file2.WriteLine(scores(q))
        Next q
        file2.Close()
        frmEndlessTally.correct = 0
        frmEndlessTally.incorrect = 0
        frmLevelSelection.Show()
        Me.Close()
    End Sub
    'Clears the name text box that is defaulted to say "Enter name"
    Private Sub txtName_Click(sender As Object, e As EventArgs) Handles txtName.Click
        txtName.Text = ""
        txtName.Select()
    End Sub

End Class