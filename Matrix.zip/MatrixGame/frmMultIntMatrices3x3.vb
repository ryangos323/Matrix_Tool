﻿Public Class frmMultIntMatrices3x3
    Dim B1temp As Decimal
    Dim B2temp As Decimal
    Dim B3temp As Decimal
    Dim B4temp As Decimal
    Dim B5temp As Decimal
    Dim B6temp As Decimal
    Dim B7temp As Decimal
    Dim B8temp As Decimal
    Dim B9temp As Decimal

    Dim C1 As Decimal
    Dim C2 As Decimal
    Dim C3 As Decimal
    Dim C4 As Decimal
    Dim C5 As Decimal
    Dim C6 As Decimal
    Dim C7 As Decimal
    Dim C8 As Decimal
    Dim C9 As Decimal

    Public Property correct As Boolean = False
    Dim i As Integer = 0
    Dim questionsToSolve As Integer = frmCustomModeSetupIntermediate.questionsToSolve
    Dim lowerBound As Integer = frmCustomModeSetupIntermediate.lowerBound
    Dim upperBound As Integer = frmCustomModeSetupIntermediate.upperBound
    Public Property isStory As Boolean = False
    Public Property isStoryDone As Boolean = False
    Public Property storyCounter As Integer = 2
    'Checks if submitted answer corresponds to correct answer for randomly generated matrix expression
    'Handles if question came from story or custom mode
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        If isStory = False Then

            Try
                If B1temp.Equals(CDec(txtB1.Text)) And B2temp.Equals(CDec(txtB2.Text)) And B3temp.Equals(CDec(txtB3.Text)) And B4temp.Equals(CDec(txtB4.Text)) And B5temp.Equals(CDec(txtB5.Text)) And B6temp.Equals(CDec(txtB6.Text)) And B7temp.Equals(CDec(txtB7.Text)) And B8temp.Equals(CDec(txtB8.Text)) And B9temp.Equals(CDec(txtB9.Text)) Then
                    correct = True
                Else
                    correct = False
                End If

                If correct = True Then
                    Dim message As String = "You got it correct."
                    Dim caption As String = "Correct!"
                    Dim button As MessageBoxButtons = MessageBoxButtons.OK
                    Dim correctMessage As DialogResult
                    correctMessage = MessageBox.Show(message, caption, button)
                    i += 1

                Else
                    Dim message As String = "You got it incorrect."
                    Dim caption As String = "Incorrect!"
                    Dim button As MessageBoxButtons = MessageBoxButtons.OK
                    Dim incorrectMessage As DialogResult
                    incorrectMessage = MessageBox.Show(message, caption, button)
                    i += 1
                End If

                If i = questionsToSolve And frmLevelSelection.isStory = False Then
                    Dim message2 As String = "You completed all questions."
                    Dim caption2 As String = "Complete!"
                    Dim button2 As MessageBoxButtons = MessageBoxButtons.OK
                    Dim completeMessage As DialogResult
                    completeMessage = MessageBox.Show(message2, caption2, button2)

                    frmLevelSelection.Show()
                    Me.Close()
                End If

                frmMultIntMatrices3x3_Load(e, e)
                txtC1.Clear()
                txtC2.Clear()
                txtC3.Clear()
                txtC4.Clear()
                txtC5.Clear()
                txtC6.Clear()
                txtC7.Clear()
                txtC8.Clear()
                txtC9.Clear()
                txtC1.Focus()
            Catch ex As InvalidCastException
                MessageBox.Show("Please enter only numbers.", "Error")
            Catch ex As ArgumentException
                MessageBox.Show("Please enter only numbers.", "Error")
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.StackTrace)
            End Try
        Else

            Try
                If B1temp.Equals(CDec(txtB1.Text)) And B2temp.Equals(CDec(txtB2.Text)) And B3temp.Equals(CDec(txtB3.Text)) And B4temp.Equals(CDec(txtB4.Text)) And B5temp.Equals(CDec(txtB5.Text)) And B6temp.Equals(CDec(txtB6.Text)) And B7temp.Equals(CDec(txtB7.Text)) And B8temp.Equals(CDec(txtB8.Text)) And B9temp.Equals(CDec(txtB9.Text)) Then
                    correct = True
                Else
                    correct = False
                End If

                If correct = True Then
                    Dim message As String = "You got it correct."
                    Dim caption As String = "Correct!"
                    Dim button As MessageBoxButtons = MessageBoxButtons.OK
                    Dim correctMessage As DialogResult
                    correctMessage = MessageBox.Show(message, caption, button)
                    i += 1

                    frmStoryModeExecution.counter += 1
                    frmStoryModeExecution.btnNextQuestion.Enabled = True
                    Me.Close()
                Else
                    Dim message As String = "You got it incorrect."
                    Dim caption As String = "Incorrect!"
                    Dim button As MessageBoxButtons = MessageBoxButtons.OK
                    Dim incorrectMessage As DialogResult
                    incorrectMessage = MessageBox.Show(message, caption, button)
                    i += 1
                End If

                frmMultIntMatrices3x3_Load(e, e)
                txtB1.Clear()
                txtB2.Clear()
                txtB3.Clear()
                txtB4.Clear()
                txtB5.Clear()
                txtB6.Clear()
                txtB7.Clear()
                txtB8.Clear()
                txtB9.Clear()

                txtB1.Focus()
            Catch ex As InvalidCastException
                MessageBox.Show("Please enter only numbers.", "Error")
            Catch ex As ArgumentException
                MessageBox.Show("Please enter only numbers.", "Error")
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.StackTrace)
            End Try
        End If
    End Sub
    'Randomly generates matrix expression with specified bounds
    Private Sub frmMultIntMatrices3x3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        txtA1.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA2.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA3.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA4.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA5.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA6.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA7.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA8.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA9.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString

        B1temp = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound)
        B2temp = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound)
        B3temp = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound)
        B4temp = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound)
        B5temp = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound)
        B6temp = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound)
        B7temp = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound)
        B8temp = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound)
        B9temp = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound)

        C1 = (CDec(txtA1.Text) * B1temp) + (CDec(txtA2.Text) * B4temp) + (CDec(txtA3.Text) * B7temp)
        C2 = (CDec(txtA1.Text) * B2temp) + (CDec(txtA2.Text) * B5temp) + (CDec(txtA3.Text) * B8temp)
        C3 = (CDec(txtA1.Text) * B3temp) + (CDec(txtA2.Text) * B6temp) + (CDec(txtA3.Text) * B9temp)
        C4 = (CDec(txtA4.Text) * B1temp) + (CDec(txtA5.Text) * B4temp) + (CDec(txtA6.Text) * B7temp)
        C5 = (CDec(txtA4.Text) * B2temp) + (CDec(txtA5.Text) * B5temp) + (CDec(txtA6.Text) * B8temp)
        C6 = (CDec(txtA4.Text) * B3temp) + (CDec(txtA5.Text) * B6temp) + (CDec(txtA6.Text) * B9temp)
        C7 = (CDec(txtA7.Text) * B1temp) + (CDec(txtA8.Text) * B4temp) + (CDec(txtA9.Text) * B7temp)
        C8 = (CDec(txtA7.Text) * B2temp) + (CDec(txtA8.Text) * B5temp) + (CDec(txtA9.Text) * B8temp)
        C9 = (CDec(txtA7.Text) * B3temp) + (CDec(txtA8.Text) * B6temp) + (CDec(txtA9.Text) * B9temp)

        txtC1.Text = C1.ToString
        txtC2.Text = C2.ToString
        txtC3.Text = C3.ToString
        txtC4.Text = C4.ToString
        txtC5.Text = C5.ToString
        txtC6.Text = C6.ToString
        txtC7.Text = C7.ToString
        txtC8.Text = C8.ToString
        txtC9.Text = C9.ToString

    End Sub
    'Displays dialog help box for intermediate multiplication
    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        dlgHelpIntMultiplication.Show()

    End Sub
    'Exits the program
    Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        Me.Close()
    End Sub
End Class