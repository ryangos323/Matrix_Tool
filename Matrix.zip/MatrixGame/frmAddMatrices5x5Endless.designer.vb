﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddMatrices5x5Endless
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtC19 = New System.Windows.Forms.TextBox()
        Me.txtC16 = New System.Windows.Forms.TextBox()
        Me.txtC17 = New System.Windows.Forms.TextBox()
        Me.txtC18 = New System.Windows.Forms.TextBox()
        Me.txtC4 = New System.Windows.Forms.TextBox()
        Me.txtC9 = New System.Windows.Forms.TextBox()
        Me.txtC14 = New System.Windows.Forms.TextBox()
        Me.txtA16 = New System.Windows.Forms.TextBox()
        Me.txtA17 = New System.Windows.Forms.TextBox()
        Me.txtA18 = New System.Windows.Forms.TextBox()
        Me.txtA19 = New System.Windows.Forms.TextBox()
        Me.txtA14 = New System.Windows.Forms.TextBox()
        Me.txtA9 = New System.Windows.Forms.TextBox()
        Me.txtA4 = New System.Windows.Forms.TextBox()
        Me.txtC12 = New System.Windows.Forms.TextBox()
        Me.txtC2 = New System.Windows.Forms.TextBox()
        Me.txtC3 = New System.Windows.Forms.TextBox()
        Me.txtC6 = New System.Windows.Forms.TextBox()
        Me.txtC7 = New System.Windows.Forms.TextBox()
        Me.txtC8 = New System.Windows.Forms.TextBox()
        Me.txtC11 = New System.Windows.Forms.TextBox()
        Me.txtC13 = New System.Windows.Forms.TextBox()
        Me.txtC1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtA12 = New System.Windows.Forms.TextBox()
        Me.txtA2 = New System.Windows.Forms.TextBox()
        Me.txtA3 = New System.Windows.Forms.TextBox()
        Me.txtA6 = New System.Windows.Forms.TextBox()
        Me.txtA7 = New System.Windows.Forms.TextBox()
        Me.txtA8 = New System.Windows.Forms.TextBox()
        Me.txtA11 = New System.Windows.Forms.TextBox()
        Me.txtA13 = New System.Windows.Forms.TextBox()
        Me.txtA1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtA5 = New System.Windows.Forms.TextBox()
        Me.txtA10 = New System.Windows.Forms.TextBox()
        Me.txtA15 = New System.Windows.Forms.TextBox()
        Me.txtA20 = New System.Windows.Forms.TextBox()
        Me.txtA25 = New System.Windows.Forms.TextBox()
        Me.txtA24 = New System.Windows.Forms.TextBox()
        Me.txtA23 = New System.Windows.Forms.TextBox()
        Me.txtA22 = New System.Windows.Forms.TextBox()
        Me.txtA21 = New System.Windows.Forms.TextBox()
        Me.txtC5 = New System.Windows.Forms.TextBox()
        Me.txtC10 = New System.Windows.Forms.TextBox()
        Me.txtC20 = New System.Windows.Forms.TextBox()
        Me.txtC25 = New System.Windows.Forms.TextBox()
        Me.txtC24 = New System.Windows.Forms.TextBox()
        Me.txtC23 = New System.Windows.Forms.TextBox()
        Me.txtC22 = New System.Windows.Forms.TextBox()
        Me.txtC21 = New System.Windows.Forms.TextBox()
        Me.txtC15 = New System.Windows.Forms.TextBox()
        Me.txtB1 = New System.Windows.Forms.TextBox()
        Me.txtB13 = New System.Windows.Forms.TextBox()
        Me.txtB11 = New System.Windows.Forms.TextBox()
        Me.txtB8 = New System.Windows.Forms.TextBox()
        Me.txtB7 = New System.Windows.Forms.TextBox()
        Me.txtB6 = New System.Windows.Forms.TextBox()
        Me.txtB3 = New System.Windows.Forms.TextBox()
        Me.txtB2 = New System.Windows.Forms.TextBox()
        Me.txtB12 = New System.Windows.Forms.TextBox()
        Me.txtB14 = New System.Windows.Forms.TextBox()
        Me.txtB18 = New System.Windows.Forms.TextBox()
        Me.txtB19 = New System.Windows.Forms.TextBox()
        Me.txtB4 = New System.Windows.Forms.TextBox()
        Me.txtB9 = New System.Windows.Forms.TextBox()
        Me.txtB16 = New System.Windows.Forms.TextBox()
        Me.txtB17 = New System.Windows.Forms.TextBox()
        Me.txtB5 = New System.Windows.Forms.TextBox()
        Me.txtB10 = New System.Windows.Forms.TextBox()
        Me.txtB15 = New System.Windows.Forms.TextBox()
        Me.txtB20 = New System.Windows.Forms.TextBox()
        Me.txtB25 = New System.Windows.Forms.TextBox()
        Me.txtB24 = New System.Windows.Forms.TextBox()
        Me.txtB23 = New System.Windows.Forms.TextBox()
        Me.txtB22 = New System.Windows.Forms.TextBox()
        Me.txtB21 = New System.Windows.Forms.TextBox()
        Me.btnQuit = New System.Windows.Forms.Button()
        Me.btnHelp = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtC19
        '
        Me.txtC19.Location = New System.Drawing.Point(921, 143)
        Me.txtC19.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC19.Name = "txtC19"
        Me.txtC19.Size = New System.Drawing.Size(56, 20)
        Me.txtC19.TabIndex = 19
        '
        'txtC16
        '
        Me.txtC16.Location = New System.Drawing.Point(742, 143)
        Me.txtC16.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC16.Name = "txtC16"
        Me.txtC16.Size = New System.Drawing.Size(56, 20)
        Me.txtC16.TabIndex = 16
        '
        'txtC17
        '
        Me.txtC17.Location = New System.Drawing.Point(802, 143)
        Me.txtC17.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC17.Name = "txtC17"
        Me.txtC17.Size = New System.Drawing.Size(56, 20)
        Me.txtC17.TabIndex = 17
        '
        'txtC18
        '
        Me.txtC18.Location = New System.Drawing.Point(862, 143)
        Me.txtC18.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC18.Name = "txtC18"
        Me.txtC18.Size = New System.Drawing.Size(56, 20)
        Me.txtC18.TabIndex = 18
        '
        'txtC4
        '
        Me.txtC4.Location = New System.Drawing.Point(921, 77)
        Me.txtC4.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC4.Name = "txtC4"
        Me.txtC4.Size = New System.Drawing.Size(56, 20)
        Me.txtC4.TabIndex = 4
        '
        'txtC9
        '
        Me.txtC9.Location = New System.Drawing.Point(921, 99)
        Me.txtC9.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC9.Name = "txtC9"
        Me.txtC9.Size = New System.Drawing.Size(56, 20)
        Me.txtC9.TabIndex = 9
        '
        'txtC14
        '
        Me.txtC14.Location = New System.Drawing.Point(921, 122)
        Me.txtC14.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC14.Name = "txtC14"
        Me.txtC14.Size = New System.Drawing.Size(56, 20)
        Me.txtC14.TabIndex = 14
        '
        'txtA16
        '
        Me.txtA16.Location = New System.Drawing.Point(32, 143)
        Me.txtA16.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA16.Name = "txtA16"
        Me.txtA16.ReadOnly = True
        Me.txtA16.Size = New System.Drawing.Size(56, 20)
        Me.txtA16.TabIndex = 136
        Me.txtA16.TabStop = False
        '
        'txtA17
        '
        Me.txtA17.Location = New System.Drawing.Point(92, 143)
        Me.txtA17.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA17.Name = "txtA17"
        Me.txtA17.ReadOnly = True
        Me.txtA17.Size = New System.Drawing.Size(56, 20)
        Me.txtA17.TabIndex = 135
        Me.txtA17.TabStop = False
        '
        'txtA18
        '
        Me.txtA18.Location = New System.Drawing.Point(152, 143)
        Me.txtA18.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA18.Name = "txtA18"
        Me.txtA18.ReadOnly = True
        Me.txtA18.Size = New System.Drawing.Size(56, 20)
        Me.txtA18.TabIndex = 134
        Me.txtA18.TabStop = False
        '
        'txtA19
        '
        Me.txtA19.Location = New System.Drawing.Point(212, 143)
        Me.txtA19.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA19.Name = "txtA19"
        Me.txtA19.ReadOnly = True
        Me.txtA19.Size = New System.Drawing.Size(56, 20)
        Me.txtA19.TabIndex = 133
        Me.txtA19.TabStop = False
        '
        'txtA14
        '
        Me.txtA14.Location = New System.Drawing.Point(212, 122)
        Me.txtA14.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA14.Name = "txtA14"
        Me.txtA14.ReadOnly = True
        Me.txtA14.Size = New System.Drawing.Size(56, 20)
        Me.txtA14.TabIndex = 132
        Me.txtA14.TabStop = False
        '
        'txtA9
        '
        Me.txtA9.Location = New System.Drawing.Point(212, 99)
        Me.txtA9.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA9.Name = "txtA9"
        Me.txtA9.ReadOnly = True
        Me.txtA9.Size = New System.Drawing.Size(56, 20)
        Me.txtA9.TabIndex = 131
        Me.txtA9.TabStop = False
        '
        'txtA4
        '
        Me.txtA4.Location = New System.Drawing.Point(212, 77)
        Me.txtA4.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA4.Name = "txtA4"
        Me.txtA4.ReadOnly = True
        Me.txtA4.Size = New System.Drawing.Size(56, 20)
        Me.txtA4.TabIndex = 130
        Me.txtA4.TabStop = False
        '
        'txtC12
        '
        Me.txtC12.Location = New System.Drawing.Point(802, 122)
        Me.txtC12.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC12.Name = "txtC12"
        Me.txtC12.Size = New System.Drawing.Size(56, 20)
        Me.txtC12.TabIndex = 12
        '
        'txtC2
        '
        Me.txtC2.Location = New System.Drawing.Point(802, 77)
        Me.txtC2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC2.Name = "txtC2"
        Me.txtC2.Size = New System.Drawing.Size(56, 20)
        Me.txtC2.TabIndex = 2
        '
        'txtC3
        '
        Me.txtC3.Location = New System.Drawing.Point(862, 77)
        Me.txtC3.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC3.Name = "txtC3"
        Me.txtC3.Size = New System.Drawing.Size(56, 20)
        Me.txtC3.TabIndex = 3
        '
        'txtC6
        '
        Me.txtC6.Location = New System.Drawing.Point(742, 99)
        Me.txtC6.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC6.Name = "txtC6"
        Me.txtC6.Size = New System.Drawing.Size(56, 20)
        Me.txtC6.TabIndex = 6
        '
        'txtC7
        '
        Me.txtC7.Location = New System.Drawing.Point(802, 99)
        Me.txtC7.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC7.Name = "txtC7"
        Me.txtC7.Size = New System.Drawing.Size(56, 20)
        Me.txtC7.TabIndex = 7
        '
        'txtC8
        '
        Me.txtC8.Location = New System.Drawing.Point(862, 99)
        Me.txtC8.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC8.Name = "txtC8"
        Me.txtC8.Size = New System.Drawing.Size(56, 20)
        Me.txtC8.TabIndex = 8
        '
        'txtC11
        '
        Me.txtC11.Location = New System.Drawing.Point(742, 122)
        Me.txtC11.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC11.Name = "txtC11"
        Me.txtC11.Size = New System.Drawing.Size(56, 20)
        Me.txtC11.TabIndex = 11
        '
        'txtC13
        '
        Me.txtC13.Location = New System.Drawing.Point(862, 122)
        Me.txtC13.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC13.Name = "txtC13"
        Me.txtC13.Size = New System.Drawing.Size(56, 20)
        Me.txtC13.TabIndex = 13
        '
        'txtC1
        '
        Me.txtC1.Location = New System.Drawing.Point(742, 77)
        Me.txtC1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC1.Name = "txtC1"
        Me.txtC1.Size = New System.Drawing.Size(56, 20)
        Me.txtC1.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(740, 41)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(136, 20)
        Me.Label5.TabIndex = 111
        Me.Label5.Text = "Solve for Matrix C:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(699, 109)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(30, 31)
        Me.Label4.TabIndex = 110
        Me.Label4.Text = "="
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(346, 110)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 31)
        Me.Label3.TabIndex = 109
        Me.Label3.Text = "+"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(388, 41)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 20)
        Me.Label2.TabIndex = 99
        Me.Label2.Text = "Matrix B:"
        '
        'txtA12
        '
        Me.txtA12.Location = New System.Drawing.Point(92, 122)
        Me.txtA12.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA12.Name = "txtA12"
        Me.txtA12.ReadOnly = True
        Me.txtA12.Size = New System.Drawing.Size(56, 20)
        Me.txtA12.TabIndex = 98
        Me.txtA12.TabStop = False
        '
        'txtA2
        '
        Me.txtA2.Location = New System.Drawing.Point(92, 77)
        Me.txtA2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA2.Name = "txtA2"
        Me.txtA2.ReadOnly = True
        Me.txtA2.Size = New System.Drawing.Size(56, 20)
        Me.txtA2.TabIndex = 97
        Me.txtA2.TabStop = False
        '
        'txtA3
        '
        Me.txtA3.Location = New System.Drawing.Point(152, 77)
        Me.txtA3.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA3.Name = "txtA3"
        Me.txtA3.ReadOnly = True
        Me.txtA3.Size = New System.Drawing.Size(56, 20)
        Me.txtA3.TabIndex = 96
        Me.txtA3.TabStop = False
        '
        'txtA6
        '
        Me.txtA6.Location = New System.Drawing.Point(32, 99)
        Me.txtA6.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA6.Name = "txtA6"
        Me.txtA6.ReadOnly = True
        Me.txtA6.Size = New System.Drawing.Size(56, 20)
        Me.txtA6.TabIndex = 95
        Me.txtA6.TabStop = False
        '
        'txtA7
        '
        Me.txtA7.Location = New System.Drawing.Point(92, 99)
        Me.txtA7.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA7.Name = "txtA7"
        Me.txtA7.ReadOnly = True
        Me.txtA7.Size = New System.Drawing.Size(56, 20)
        Me.txtA7.TabIndex = 94
        Me.txtA7.TabStop = False
        '
        'txtA8
        '
        Me.txtA8.Location = New System.Drawing.Point(152, 99)
        Me.txtA8.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA8.Name = "txtA8"
        Me.txtA8.ReadOnly = True
        Me.txtA8.Size = New System.Drawing.Size(56, 20)
        Me.txtA8.TabIndex = 93
        Me.txtA8.TabStop = False
        '
        'txtA11
        '
        Me.txtA11.Location = New System.Drawing.Point(32, 122)
        Me.txtA11.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA11.Name = "txtA11"
        Me.txtA11.ReadOnly = True
        Me.txtA11.Size = New System.Drawing.Size(56, 20)
        Me.txtA11.TabIndex = 92
        Me.txtA11.TabStop = False
        '
        'txtA13
        '
        Me.txtA13.Location = New System.Drawing.Point(152, 122)
        Me.txtA13.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA13.Name = "txtA13"
        Me.txtA13.ReadOnly = True
        Me.txtA13.Size = New System.Drawing.Size(56, 20)
        Me.txtA13.TabIndex = 91
        Me.txtA13.TabStop = False
        '
        'txtA1
        '
        Me.txtA1.Location = New System.Drawing.Point(32, 77)
        Me.txtA1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA1.Name = "txtA1"
        Me.txtA1.ReadOnly = True
        Me.txtA1.Size = New System.Drawing.Size(56, 20)
        Me.txtA1.TabIndex = 90
        Me.txtA1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(30, 41)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(70, 20)
        Me.Label1.TabIndex = 89
        Me.Label1.Text = "Matrix A:"
        '
        'txtA5
        '
        Me.txtA5.Location = New System.Drawing.Point(271, 77)
        Me.txtA5.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA5.Name = "txtA5"
        Me.txtA5.ReadOnly = True
        Me.txtA5.Size = New System.Drawing.Size(56, 20)
        Me.txtA5.TabIndex = 153
        Me.txtA5.TabStop = False
        '
        'txtA10
        '
        Me.txtA10.Location = New System.Drawing.Point(271, 99)
        Me.txtA10.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA10.Name = "txtA10"
        Me.txtA10.ReadOnly = True
        Me.txtA10.Size = New System.Drawing.Size(56, 20)
        Me.txtA10.TabIndex = 154
        Me.txtA10.TabStop = False
        '
        'txtA15
        '
        Me.txtA15.Location = New System.Drawing.Point(271, 122)
        Me.txtA15.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA15.Name = "txtA15"
        Me.txtA15.ReadOnly = True
        Me.txtA15.Size = New System.Drawing.Size(56, 20)
        Me.txtA15.TabIndex = 155
        Me.txtA15.TabStop = False
        '
        'txtA20
        '
        Me.txtA20.Location = New System.Drawing.Point(271, 143)
        Me.txtA20.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA20.Name = "txtA20"
        Me.txtA20.ReadOnly = True
        Me.txtA20.Size = New System.Drawing.Size(56, 20)
        Me.txtA20.TabIndex = 156
        Me.txtA20.TabStop = False
        '
        'txtA25
        '
        Me.txtA25.Location = New System.Drawing.Point(271, 164)
        Me.txtA25.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA25.Name = "txtA25"
        Me.txtA25.ReadOnly = True
        Me.txtA25.Size = New System.Drawing.Size(56, 20)
        Me.txtA25.TabIndex = 157
        Me.txtA25.TabStop = False
        '
        'txtA24
        '
        Me.txtA24.Location = New System.Drawing.Point(212, 164)
        Me.txtA24.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA24.Name = "txtA24"
        Me.txtA24.ReadOnly = True
        Me.txtA24.Size = New System.Drawing.Size(56, 20)
        Me.txtA24.TabIndex = 158
        Me.txtA24.TabStop = False
        '
        'txtA23
        '
        Me.txtA23.Location = New System.Drawing.Point(152, 164)
        Me.txtA23.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA23.Name = "txtA23"
        Me.txtA23.ReadOnly = True
        Me.txtA23.Size = New System.Drawing.Size(56, 20)
        Me.txtA23.TabIndex = 159
        Me.txtA23.TabStop = False
        '
        'txtA22
        '
        Me.txtA22.Location = New System.Drawing.Point(92, 164)
        Me.txtA22.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA22.Name = "txtA22"
        Me.txtA22.ReadOnly = True
        Me.txtA22.Size = New System.Drawing.Size(56, 20)
        Me.txtA22.TabIndex = 160
        Me.txtA22.TabStop = False
        '
        'txtA21
        '
        Me.txtA21.Location = New System.Drawing.Point(32, 164)
        Me.txtA21.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA21.Name = "txtA21"
        Me.txtA21.ReadOnly = True
        Me.txtA21.Size = New System.Drawing.Size(56, 20)
        Me.txtA21.TabIndex = 161
        Me.txtA21.TabStop = False
        '
        'txtC5
        '
        Me.txtC5.Location = New System.Drawing.Point(980, 78)
        Me.txtC5.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC5.Name = "txtC5"
        Me.txtC5.Size = New System.Drawing.Size(56, 20)
        Me.txtC5.TabIndex = 5
        '
        'txtC10
        '
        Me.txtC10.Location = New System.Drawing.Point(980, 99)
        Me.txtC10.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC10.Name = "txtC10"
        Me.txtC10.Size = New System.Drawing.Size(56, 20)
        Me.txtC10.TabIndex = 10
        '
        'txtC20
        '
        Me.txtC20.Location = New System.Drawing.Point(980, 143)
        Me.txtC20.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC20.Name = "txtC20"
        Me.txtC20.Size = New System.Drawing.Size(56, 20)
        Me.txtC20.TabIndex = 20
        '
        'txtC25
        '
        Me.txtC25.Location = New System.Drawing.Point(980, 164)
        Me.txtC25.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC25.Name = "txtC25"
        Me.txtC25.Size = New System.Drawing.Size(56, 20)
        Me.txtC25.TabIndex = 25
        '
        'txtC24
        '
        Me.txtC24.Location = New System.Drawing.Point(921, 164)
        Me.txtC24.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC24.Name = "txtC24"
        Me.txtC24.Size = New System.Drawing.Size(56, 20)
        Me.txtC24.TabIndex = 24
        '
        'txtC23
        '
        Me.txtC23.Location = New System.Drawing.Point(862, 164)
        Me.txtC23.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC23.Name = "txtC23"
        Me.txtC23.Size = New System.Drawing.Size(56, 20)
        Me.txtC23.TabIndex = 23
        '
        'txtC22
        '
        Me.txtC22.Location = New System.Drawing.Point(802, 164)
        Me.txtC22.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC22.Name = "txtC22"
        Me.txtC22.Size = New System.Drawing.Size(56, 20)
        Me.txtC22.TabIndex = 22
        '
        'txtC21
        '
        Me.txtC21.Location = New System.Drawing.Point(742, 164)
        Me.txtC21.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC21.Name = "txtC21"
        Me.txtC21.Size = New System.Drawing.Size(56, 20)
        Me.txtC21.TabIndex = 21
        '
        'txtC15
        '
        Me.txtC15.Location = New System.Drawing.Point(980, 121)
        Me.txtC15.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC15.Name = "txtC15"
        Me.txtC15.Size = New System.Drawing.Size(56, 20)
        Me.txtC15.TabIndex = 15
        '
        'txtB1
        '
        Me.txtB1.Location = New System.Drawing.Point(391, 77)
        Me.txtB1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB1.Name = "txtB1"
        Me.txtB1.ReadOnly = True
        Me.txtB1.Size = New System.Drawing.Size(56, 20)
        Me.txtB1.TabIndex = 100
        Me.txtB1.TabStop = False
        '
        'txtB13
        '
        Me.txtB13.Location = New System.Drawing.Point(511, 122)
        Me.txtB13.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB13.Name = "txtB13"
        Me.txtB13.ReadOnly = True
        Me.txtB13.Size = New System.Drawing.Size(56, 20)
        Me.txtB13.TabIndex = 101
        Me.txtB13.TabStop = False
        '
        'txtB11
        '
        Me.txtB11.Location = New System.Drawing.Point(391, 122)
        Me.txtB11.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB11.Name = "txtB11"
        Me.txtB11.ReadOnly = True
        Me.txtB11.Size = New System.Drawing.Size(56, 20)
        Me.txtB11.TabIndex = 102
        Me.txtB11.TabStop = False
        '
        'txtB8
        '
        Me.txtB8.Location = New System.Drawing.Point(511, 99)
        Me.txtB8.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB8.Name = "txtB8"
        Me.txtB8.ReadOnly = True
        Me.txtB8.Size = New System.Drawing.Size(56, 20)
        Me.txtB8.TabIndex = 103
        Me.txtB8.TabStop = False
        '
        'txtB7
        '
        Me.txtB7.Location = New System.Drawing.Point(451, 99)
        Me.txtB7.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB7.Name = "txtB7"
        Me.txtB7.ReadOnly = True
        Me.txtB7.Size = New System.Drawing.Size(56, 20)
        Me.txtB7.TabIndex = 104
        Me.txtB7.TabStop = False
        '
        'txtB6
        '
        Me.txtB6.Location = New System.Drawing.Point(391, 99)
        Me.txtB6.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB6.Name = "txtB6"
        Me.txtB6.ReadOnly = True
        Me.txtB6.Size = New System.Drawing.Size(56, 20)
        Me.txtB6.TabIndex = 105
        Me.txtB6.TabStop = False
        '
        'txtB3
        '
        Me.txtB3.Location = New System.Drawing.Point(511, 77)
        Me.txtB3.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB3.Name = "txtB3"
        Me.txtB3.ReadOnly = True
        Me.txtB3.Size = New System.Drawing.Size(56, 20)
        Me.txtB3.TabIndex = 106
        Me.txtB3.TabStop = False
        '
        'txtB2
        '
        Me.txtB2.Location = New System.Drawing.Point(451, 77)
        Me.txtB2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB2.Name = "txtB2"
        Me.txtB2.ReadOnly = True
        Me.txtB2.Size = New System.Drawing.Size(56, 20)
        Me.txtB2.TabIndex = 107
        Me.txtB2.TabStop = False
        '
        'txtB12
        '
        Me.txtB12.Location = New System.Drawing.Point(451, 122)
        Me.txtB12.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB12.Name = "txtB12"
        Me.txtB12.ReadOnly = True
        Me.txtB12.Size = New System.Drawing.Size(56, 20)
        Me.txtB12.TabIndex = 108
        Me.txtB12.TabStop = False
        '
        'txtB14
        '
        Me.txtB14.Location = New System.Drawing.Point(570, 122)
        Me.txtB14.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB14.Name = "txtB14"
        Me.txtB14.ReadOnly = True
        Me.txtB14.Size = New System.Drawing.Size(56, 20)
        Me.txtB14.TabIndex = 123
        Me.txtB14.TabStop = False
        '
        'txtB18
        '
        Me.txtB18.Location = New System.Drawing.Point(511, 143)
        Me.txtB18.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB18.Name = "txtB18"
        Me.txtB18.ReadOnly = True
        Me.txtB18.Size = New System.Drawing.Size(56, 20)
        Me.txtB18.TabIndex = 124
        Me.txtB18.TabStop = False
        '
        'txtB19
        '
        Me.txtB19.Location = New System.Drawing.Point(570, 143)
        Me.txtB19.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB19.Name = "txtB19"
        Me.txtB19.ReadOnly = True
        Me.txtB19.Size = New System.Drawing.Size(56, 20)
        Me.txtB19.TabIndex = 125
        Me.txtB19.TabStop = False
        '
        'txtB4
        '
        Me.txtB4.Location = New System.Drawing.Point(570, 77)
        Me.txtB4.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB4.Name = "txtB4"
        Me.txtB4.ReadOnly = True
        Me.txtB4.Size = New System.Drawing.Size(56, 20)
        Me.txtB4.TabIndex = 126
        Me.txtB4.TabStop = False
        '
        'txtB9
        '
        Me.txtB9.Location = New System.Drawing.Point(570, 99)
        Me.txtB9.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB9.Name = "txtB9"
        Me.txtB9.ReadOnly = True
        Me.txtB9.Size = New System.Drawing.Size(56, 20)
        Me.txtB9.TabIndex = 127
        Me.txtB9.TabStop = False
        '
        'txtB16
        '
        Me.txtB16.Location = New System.Drawing.Point(392, 143)
        Me.txtB16.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB16.Name = "txtB16"
        Me.txtB16.ReadOnly = True
        Me.txtB16.Size = New System.Drawing.Size(56, 20)
        Me.txtB16.TabIndex = 128
        Me.txtB16.TabStop = False
        '
        'txtB17
        '
        Me.txtB17.Location = New System.Drawing.Point(451, 143)
        Me.txtB17.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB17.Name = "txtB17"
        Me.txtB17.ReadOnly = True
        Me.txtB17.Size = New System.Drawing.Size(56, 20)
        Me.txtB17.TabIndex = 129
        Me.txtB17.TabStop = False
        '
        'txtB5
        '
        Me.txtB5.Location = New System.Drawing.Point(629, 78)
        Me.txtB5.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB5.Name = "txtB5"
        Me.txtB5.ReadOnly = True
        Me.txtB5.Size = New System.Drawing.Size(56, 20)
        Me.txtB5.TabIndex = 144
        Me.txtB5.TabStop = False
        '
        'txtB10
        '
        Me.txtB10.Location = New System.Drawing.Point(629, 99)
        Me.txtB10.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB10.Name = "txtB10"
        Me.txtB10.ReadOnly = True
        Me.txtB10.Size = New System.Drawing.Size(56, 20)
        Me.txtB10.TabIndex = 145
        Me.txtB10.TabStop = False
        '
        'txtB15
        '
        Me.txtB15.Location = New System.Drawing.Point(629, 122)
        Me.txtB15.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB15.Name = "txtB15"
        Me.txtB15.ReadOnly = True
        Me.txtB15.Size = New System.Drawing.Size(56, 20)
        Me.txtB15.TabIndex = 146
        Me.txtB15.TabStop = False
        '
        'txtB20
        '
        Me.txtB20.Location = New System.Drawing.Point(629, 143)
        Me.txtB20.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB20.Name = "txtB20"
        Me.txtB20.ReadOnly = True
        Me.txtB20.Size = New System.Drawing.Size(56, 20)
        Me.txtB20.TabIndex = 147
        Me.txtB20.TabStop = False
        '
        'txtB25
        '
        Me.txtB25.Location = New System.Drawing.Point(629, 164)
        Me.txtB25.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB25.Name = "txtB25"
        Me.txtB25.ReadOnly = True
        Me.txtB25.Size = New System.Drawing.Size(56, 20)
        Me.txtB25.TabIndex = 148
        Me.txtB25.TabStop = False
        '
        'txtB24
        '
        Me.txtB24.Location = New System.Drawing.Point(570, 164)
        Me.txtB24.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB24.Name = "txtB24"
        Me.txtB24.ReadOnly = True
        Me.txtB24.Size = New System.Drawing.Size(56, 20)
        Me.txtB24.TabIndex = 149
        Me.txtB24.TabStop = False
        '
        'txtB23
        '
        Me.txtB23.Location = New System.Drawing.Point(511, 164)
        Me.txtB23.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB23.Name = "txtB23"
        Me.txtB23.ReadOnly = True
        Me.txtB23.Size = New System.Drawing.Size(56, 20)
        Me.txtB23.TabIndex = 150
        Me.txtB23.TabStop = False
        '
        'txtB22
        '
        Me.txtB22.Location = New System.Drawing.Point(450, 164)
        Me.txtB22.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB22.Name = "txtB22"
        Me.txtB22.ReadOnly = True
        Me.txtB22.Size = New System.Drawing.Size(56, 20)
        Me.txtB22.TabIndex = 151
        Me.txtB22.TabStop = False
        '
        'txtB21
        '
        Me.txtB21.Location = New System.Drawing.Point(391, 164)
        Me.txtB21.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB21.Name = "txtB21"
        Me.txtB21.ReadOnly = True
        Me.txtB21.Size = New System.Drawing.Size(56, 20)
        Me.txtB21.TabIndex = 152
        Me.txtB21.TabStop = False
        '
        'btnQuit
        '
        Me.btnQuit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnQuit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuit.Location = New System.Drawing.Point(591, 196)
        Me.btnQuit.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(77, 40)
        Me.btnQuit.TabIndex = 28
        Me.btnQuit.Text = "Quit"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'btnHelp
        '
        Me.btnHelp.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHelp.Location = New System.Drawing.Point(494, 196)
        Me.btnHelp.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(77, 40)
        Me.btnHelp.TabIndex = 27
        Me.btnHelp.Text = "Help"
        Me.btnHelp.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(398, 196)
        Me.btnSubmit.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(77, 40)
        Me.btnSubmit.TabIndex = 26
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'frmAddMatrices5x5Endless
        '
        Me.AcceptButton = Me.btnSubmit
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.CancelButton = Me.btnQuit
        Me.ClientSize = New System.Drawing.Size(1066, 276)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.btnHelp)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.txtC15)
        Me.Controls.Add(Me.txtC21)
        Me.Controls.Add(Me.txtC22)
        Me.Controls.Add(Me.txtC23)
        Me.Controls.Add(Me.txtC24)
        Me.Controls.Add(Me.txtC25)
        Me.Controls.Add(Me.txtC20)
        Me.Controls.Add(Me.txtC10)
        Me.Controls.Add(Me.txtC5)
        Me.Controls.Add(Me.txtA21)
        Me.Controls.Add(Me.txtA22)
        Me.Controls.Add(Me.txtA23)
        Me.Controls.Add(Me.txtA24)
        Me.Controls.Add(Me.txtA25)
        Me.Controls.Add(Me.txtA20)
        Me.Controls.Add(Me.txtA15)
        Me.Controls.Add(Me.txtA10)
        Me.Controls.Add(Me.txtA5)
        Me.Controls.Add(Me.txtB21)
        Me.Controls.Add(Me.txtB22)
        Me.Controls.Add(Me.txtB23)
        Me.Controls.Add(Me.txtB24)
        Me.Controls.Add(Me.txtB25)
        Me.Controls.Add(Me.txtB20)
        Me.Controls.Add(Me.txtB15)
        Me.Controls.Add(Me.txtB10)
        Me.Controls.Add(Me.txtB5)
        Me.Controls.Add(Me.txtC19)
        Me.Controls.Add(Me.txtC16)
        Me.Controls.Add(Me.txtC17)
        Me.Controls.Add(Me.txtC18)
        Me.Controls.Add(Me.txtC4)
        Me.Controls.Add(Me.txtC9)
        Me.Controls.Add(Me.txtC14)
        Me.Controls.Add(Me.txtA16)
        Me.Controls.Add(Me.txtA17)
        Me.Controls.Add(Me.txtA18)
        Me.Controls.Add(Me.txtA19)
        Me.Controls.Add(Me.txtA14)
        Me.Controls.Add(Me.txtA9)
        Me.Controls.Add(Me.txtA4)
        Me.Controls.Add(Me.txtB17)
        Me.Controls.Add(Me.txtB16)
        Me.Controls.Add(Me.txtB9)
        Me.Controls.Add(Me.txtB4)
        Me.Controls.Add(Me.txtB19)
        Me.Controls.Add(Me.txtB18)
        Me.Controls.Add(Me.txtB14)
        Me.Controls.Add(Me.txtC12)
        Me.Controls.Add(Me.txtC2)
        Me.Controls.Add(Me.txtC3)
        Me.Controls.Add(Me.txtC6)
        Me.Controls.Add(Me.txtC7)
        Me.Controls.Add(Me.txtC8)
        Me.Controls.Add(Me.txtC11)
        Me.Controls.Add(Me.txtC13)
        Me.Controls.Add(Me.txtC1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtB12)
        Me.Controls.Add(Me.txtB2)
        Me.Controls.Add(Me.txtB3)
        Me.Controls.Add(Me.txtB6)
        Me.Controls.Add(Me.txtB7)
        Me.Controls.Add(Me.txtB8)
        Me.Controls.Add(Me.txtB11)
        Me.Controls.Add(Me.txtB13)
        Me.Controls.Add(Me.txtB1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtA12)
        Me.Controls.Add(Me.txtA2)
        Me.Controls.Add(Me.txtA3)
        Me.Controls.Add(Me.txtA6)
        Me.Controls.Add(Me.txtA7)
        Me.Controls.Add(Me.txtA8)
        Me.Controls.Add(Me.txtA11)
        Me.Controls.Add(Me.txtA13)
        Me.Controls.Add(Me.txtA1)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "frmAddMatrices5x5Endless"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Addition 5x5"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtC19 As TextBox
    Friend WithEvents txtC16 As TextBox
    Friend WithEvents txtC17 As TextBox
    Friend WithEvents txtC18 As TextBox
    Friend WithEvents txtC4 As TextBox
    Friend WithEvents txtC9 As TextBox
    Friend WithEvents txtC14 As TextBox
    Friend WithEvents txtA16 As TextBox
    Friend WithEvents txtA17 As TextBox
    Friend WithEvents txtA18 As TextBox
    Friend WithEvents txtA19 As TextBox
    Friend WithEvents txtA14 As TextBox
    Friend WithEvents txtA9 As TextBox
    Friend WithEvents txtA4 As TextBox
    Friend WithEvents txtC12 As TextBox
    Friend WithEvents txtC2 As TextBox
    Friend WithEvents txtC3 As TextBox
    Friend WithEvents txtC6 As TextBox
    Friend WithEvents txtC7 As TextBox
    Friend WithEvents txtC8 As TextBox
    Friend WithEvents txtC11 As TextBox
    Friend WithEvents txtC13 As TextBox
    Friend WithEvents txtC1 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtA12 As TextBox
    Friend WithEvents txtA2 As TextBox
    Friend WithEvents txtA3 As TextBox
    Friend WithEvents txtA6 As TextBox
    Friend WithEvents txtA7 As TextBox
    Friend WithEvents txtA8 As TextBox
    Friend WithEvents txtA11 As TextBox
    Friend WithEvents txtA13 As TextBox
    Friend WithEvents txtA1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtA5 As TextBox
    Friend WithEvents txtA10 As TextBox
    Friend WithEvents txtA15 As TextBox
    Friend WithEvents txtA20 As TextBox
    Friend WithEvents txtA25 As TextBox
    Friend WithEvents txtA24 As TextBox
    Friend WithEvents txtA23 As TextBox
    Friend WithEvents txtA22 As TextBox
    Friend WithEvents txtA21 As TextBox
    Friend WithEvents txtC5 As TextBox
    Friend WithEvents txtC10 As TextBox
    Friend WithEvents txtC20 As TextBox
    Friend WithEvents txtC25 As TextBox
    Friend WithEvents txtC24 As TextBox
    Friend WithEvents txtC23 As TextBox
    Friend WithEvents txtC22 As TextBox
    Friend WithEvents txtC21 As TextBox
    Friend WithEvents txtC15 As TextBox
    Friend WithEvents txtB1 As TextBox
    Friend WithEvents txtB13 As TextBox
    Friend WithEvents txtB11 As TextBox
    Friend WithEvents txtB8 As TextBox
    Friend WithEvents txtB7 As TextBox
    Friend WithEvents txtB6 As TextBox
    Friend WithEvents txtB3 As TextBox
    Friend WithEvents txtB2 As TextBox
    Friend WithEvents txtB12 As TextBox
    Friend WithEvents txtB14 As TextBox
    Friend WithEvents txtB18 As TextBox
    Friend WithEvents txtB19 As TextBox
    Friend WithEvents txtB4 As TextBox
    Friend WithEvents txtB9 As TextBox
    Friend WithEvents txtB16 As TextBox
    Friend WithEvents txtB17 As TextBox
    Friend WithEvents txtB5 As TextBox
    Friend WithEvents txtB10 As TextBox
    Friend WithEvents txtB15 As TextBox
    Friend WithEvents txtB20 As TextBox
    Friend WithEvents txtB25 As TextBox
    Friend WithEvents txtB24 As TextBox
    Friend WithEvents txtB23 As TextBox
    Friend WithEvents txtB22 As TextBox
    Friend WithEvents txtB21 As TextBox
    Friend WithEvents btnQuit As Button
    Friend WithEvents btnHelp As Button
    Friend WithEvents btnSubmit As Button
End Class
