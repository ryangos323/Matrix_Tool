﻿Public Class frmSubIntMatrices3x3
    Dim B1 As Decimal
    Dim B2 As Decimal
    Dim B3 As Decimal
    Dim B4 As Decimal
    Dim B5 As Decimal
    Dim B6 As Decimal
    Dim B7 As Decimal
    Dim B8 As Decimal
    Dim B9 As Decimal
    Public Property correct As Boolean = False
    Dim i As Integer = 0
    Dim questionsToSolve As Integer = frmCustomModeSetupIntermediate.questionsToSolve
    Dim lowerBound As Integer = frmCustomModeSetupIntermediate.lowerBound
    Dim upperBound As Integer = frmCustomModeSetupIntermediate.upperBound
    Public Property isStory As Boolean = False
    Public Property isStoryDone As Boolean = False
    Public Property storyCounter As Integer = 2
    'Check submitted answer to correct answer to generated matrix expression
    'Handles if the problem was from story mode or custom mode 
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        If isStory = False Then

            Try
                If B1.Equals(CDec(txtB1.Text)) And B2.Equals(CDec(txtB2.Text)) And B3.Equals(CDec(txtB3.Text)) And B4.Equals(CDec(txtB4.Text)) And B5.Equals(CDec(txtB5.Text)) And B6.Equals(CDec(txtB6.Text)) And B7.Equals(CDec(txtB7.Text)) And B8.Equals(CDec(txtB8.Text)) And B9.Equals(CDec(txtB9.Text)) Then
                    correct = True
                Else
                    correct = False
                End If

                If correct = True Then
                    Dim message As String = "You got it correct."
                    Dim caption As String = "Correct!"
                    Dim button As MessageBoxButtons = MessageBoxButtons.OK
                    Dim correctMessage As DialogResult
                    correctMessage = MessageBox.Show(message, caption, button)
                    i += 1

                Else
                    Dim message As String = "You got it incorrect."
                    Dim caption As String = "Incorrect!"
                    Dim button As MessageBoxButtons = MessageBoxButtons.OK
                    Dim incorrectMessage As DialogResult
                    incorrectMessage = MessageBox.Show(message, caption, button)
                    i += 1
                End If

                If i = questionsToSolve And frmLevelSelection.isStory = False Then
                    Dim message2 As String = "You completed all questions."
                    Dim caption2 As String = "Complete!"
                    Dim button2 As MessageBoxButtons = MessageBoxButtons.OK
                    Dim completeMessage As DialogResult
                    completeMessage = MessageBox.Show(message2, caption2, button2)

                    frmLevelSelection.Show()
                    Me.Close()
                End If

                frmSubIntMatrices3x3_Load(e, e)
                txtC1.Clear()
                txtC2.Clear()
                txtC3.Clear()
                txtC4.Clear()
                txtC5.Clear()
                txtC6.Clear()
                txtC7.Clear()
                txtC8.Clear()
                txtC9.Clear()
                txtC1.Focus()
            Catch ex As InvalidCastException
                MessageBox.Show("Please enter only numbers.", "Error")
            Catch ex As ArgumentException
                MessageBox.Show("Please enter only numbers.", "Error")
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.StackTrace)
            End Try
        Else

            Try
                If B1.Equals(CDec(txtB1.Text)) And B2.Equals(CDec(txtB2.Text)) And B3.Equals(CDec(txtB3.Text)) And B4.Equals(CDec(txtB4.Text)) And B5.Equals(CDec(txtB5.Text)) And B6.Equals(CDec(txtB6.Text)) And B7.Equals(CDec(txtB7.Text)) And B8.Equals(CDec(txtB8.Text)) And B9.Equals(CDec(txtB9.Text)) Then
                    correct = True
                Else
                    correct = False
                End If

                If correct = True Then
                    Dim message As String = "You got it correct."
                    Dim caption As String = "Correct!"
                    Dim button As MessageBoxButtons = MessageBoxButtons.OK
                    Dim correctMessage As DialogResult
                    correctMessage = MessageBox.Show(message, caption, button)
                    i += 1

                    frmStoryModeExecution.counter += 1
                    frmStoryModeExecution.btnNextQuestion.Enabled = True
                    Me.Close()
                Else
                    Dim message As String = "You got it incorrect."
                    Dim caption As String = "Incorrect!"
                    Dim button As MessageBoxButtons = MessageBoxButtons.OK
                    Dim incorrectMessage As DialogResult
                    incorrectMessage = MessageBox.Show(message, caption, button)
                    i += 1
                End If

                frmSubIntMatrices3x3_Load(e, e)
                txtB1.Clear()
                txtB2.Clear()
                txtB3.Clear()
                txtB4.Clear()
                txtB5.Clear()
                txtB6.Clear()
                txtB7.Clear()
                txtB8.Clear()
                txtB9.Clear()
                txtB1.Focus()
            Catch ex As InvalidCastException
                MessageBox.Show("Please enter only numbers.", "Error")
            Catch ex As ArgumentException
                MessageBox.Show("Please enter only numbers.", "Error")
            Catch ex As Exception
                MessageBox.Show(ex.Message, ex.StackTrace)
            End Try
        End If
    End Sub
    'Generates random matrix problem with specified 
    Private Sub frmSubIntMatrices3x3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        txtA1.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA2.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA3.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA4.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA5.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA6.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA7.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA8.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtA9.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString

        txtC1.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtC2.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtC3.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtC4.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtC5.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtC6.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtC7.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtC8.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString
        txtC9.Text = (CInt(Math.Floor((upperBound - lowerBound + 1) * Rnd())) + lowerBound).ToString

        B1 = (-(CDec(txtC1.Text)) + CDec(txtA1.Text))
        B2 = (-(CDec(txtC2.Text)) + CDec(txtA2.Text))
        B3 = (-(CDec(txtC3.Text)) + CDec(txtA3.Text))
        B4 = (-(CDec(txtC4.Text)) + CDec(txtA4.Text))
        B5 = (-(CDec(txtC5.Text)) + CDec(txtA5.Text))
        B6 = (-(CDec(txtC6.Text)) + CDec(txtA6.Text))
        B7 = (-(CDec(txtC7.Text)) + CDec(txtA7.Text))
        B8 = (-(CDec(txtC8.Text)) + CDec(txtA8.Text))
        B9 = (-(CDec(txtC9.Text)) + CDec(txtA9.Text))
    End Sub
    'Displays diaglog box for intermediate subtraction
    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        dlgHelpIntSubtraction.Show()
    End Sub
    'Returns to the custom mode setup screen
    Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        frmCustomModeSetup.Show()
        Me.Close()
    End Sub
End Class