﻿Public Class frmRunningEndless
    Dim i As Integer
    'Gets a random integer which then randomly calls a form endlessly
    Private Sub frmendlesstest_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        i = (CInt(Math.Ceiling((12 - 1 + 1) * Rnd())) + 1)



        If i = 1 Then

            frmAddMatrices3x3Endless.Show()
            Me.Close()
        End If


        If i = 2 Then

            frmAddMatrices4x4Endless.Show()
            Me.Close()
        End If


        If i = 3 Then

            frmAddMatrices5x5Endless.Show()
            Me.Close()

        End If

        If i = 4 Then

            frmAddIntMatrices3x3Endless.Show()
            Me.Close()

        End If

        If i = 5 Then

            frmSubMatrices3x3Endless.Show()
            Me.Close()

        End If

        If i = 6 Then

            frmSubMatrices4x4Endless.Show()
            Me.Close()

        End If

        If i = 7 Then

            frmSubMatrices5x5Endless.Show()
            Me.Close()

        End If

        If i = 8 Then

            frmSubIntMatrices3x3Endless.Show()
            Me.Close()

        End If

        If i = 9 Then

            frmMultMatrices3x2Endless.Show()
            Me.Close()

        End If

        If i = 10 Then

            frmMultMatrices2x3Endless.Show()
            Me.Close()
        End If
        If i = 11 Then

            frmMultMatrices3x3Endless.Show()
            Me.Close()
        End If
        If i = 12 Then

            frmMultIntMatrices3x3Endless.Show()
            Me.Close()
        End If
    End Sub

End Class