﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMultMatrices2x3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtC2 = New System.Windows.Forms.TextBox()
        Me.txtC3 = New System.Windows.Forms.TextBox()
        Me.txtC4 = New System.Windows.Forms.TextBox()
        Me.txtC1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtB6 = New System.Windows.Forms.TextBox()
        Me.txtB2 = New System.Windows.Forms.TextBox()
        Me.txtB3 = New System.Windows.Forms.TextBox()
        Me.txtB4 = New System.Windows.Forms.TextBox()
        Me.txtB5 = New System.Windows.Forms.TextBox()
        Me.txtB1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtA2 = New System.Windows.Forms.TextBox()
        Me.txtA3 = New System.Windows.Forms.TextBox()
        Me.txtA4 = New System.Windows.Forms.TextBox()
        Me.txtA5 = New System.Windows.Forms.TextBox()
        Me.txtA6 = New System.Windows.Forms.TextBox()
        Me.txtA1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnQuit = New System.Windows.Forms.Button()
        Me.btnHelp = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtC2
        '
        Me.txtC2.Location = New System.Drawing.Point(548, 74)
        Me.txtC2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC2.Name = "txtC2"
        Me.txtC2.Size = New System.Drawing.Size(56, 20)
        Me.txtC2.TabIndex = 2
        '
        'txtC3
        '
        Me.txtC3.Location = New System.Drawing.Point(488, 96)
        Me.txtC3.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC3.Name = "txtC3"
        Me.txtC3.Size = New System.Drawing.Size(56, 20)
        Me.txtC3.TabIndex = 3
        '
        'txtC4
        '
        Me.txtC4.Location = New System.Drawing.Point(548, 96)
        Me.txtC4.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC4.Name = "txtC4"
        Me.txtC4.Size = New System.Drawing.Size(56, 20)
        Me.txtC4.TabIndex = 4
        '
        'txtC1
        '
        Me.txtC1.Location = New System.Drawing.Point(488, 74)
        Me.txtC1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtC1.Name = "txtC1"
        Me.txtC1.Size = New System.Drawing.Size(56, 20)
        Me.txtC1.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(484, 29)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(136, 20)
        Me.Label5.TabIndex = 90
        Me.Label5.Text = "Solve for Matrix C:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(435, 84)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(30, 31)
        Me.Label4.TabIndex = 89
        Me.Label4.Text = "="
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(241, 76)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(27, 31)
        Me.Label3.TabIndex = 88
        Me.Label3.Text = "x"
        '
        'txtB6
        '
        Me.txtB6.Location = New System.Drawing.Point(353, 110)
        Me.txtB6.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB6.Name = "txtB6"
        Me.txtB6.ReadOnly = True
        Me.txtB6.Size = New System.Drawing.Size(56, 20)
        Me.txtB6.TabIndex = 87
        Me.txtB6.TabStop = False
        '
        'txtB2
        '
        Me.txtB2.Location = New System.Drawing.Point(353, 66)
        Me.txtB2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB2.Name = "txtB2"
        Me.txtB2.ReadOnly = True
        Me.txtB2.Size = New System.Drawing.Size(56, 20)
        Me.txtB2.TabIndex = 86
        Me.txtB2.TabStop = False
        '
        'txtB3
        '
        Me.txtB3.Location = New System.Drawing.Point(293, 88)
        Me.txtB3.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB3.Name = "txtB3"
        Me.txtB3.ReadOnly = True
        Me.txtB3.Size = New System.Drawing.Size(56, 20)
        Me.txtB3.TabIndex = 84
        Me.txtB3.TabStop = False
        '
        'txtB4
        '
        Me.txtB4.Location = New System.Drawing.Point(353, 88)
        Me.txtB4.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB4.Name = "txtB4"
        Me.txtB4.ReadOnly = True
        Me.txtB4.Size = New System.Drawing.Size(56, 20)
        Me.txtB4.TabIndex = 83
        Me.txtB4.TabStop = False
        '
        'txtB5
        '
        Me.txtB5.Location = New System.Drawing.Point(293, 110)
        Me.txtB5.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB5.Name = "txtB5"
        Me.txtB5.ReadOnly = True
        Me.txtB5.Size = New System.Drawing.Size(56, 20)
        Me.txtB5.TabIndex = 81
        Me.txtB5.TabStop = False
        '
        'txtB1
        '
        Me.txtB1.Location = New System.Drawing.Point(293, 66)
        Me.txtB1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtB1.Name = "txtB1"
        Me.txtB1.ReadOnly = True
        Me.txtB1.Size = New System.Drawing.Size(56, 20)
        Me.txtB1.TabIndex = 79
        Me.txtB1.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(290, 29)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 20)
        Me.Label2.TabIndex = 78
        Me.Label2.Text = "Matrix B:"
        '
        'txtA2
        '
        Me.txtA2.Location = New System.Drawing.Point(98, 74)
        Me.txtA2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA2.Name = "txtA2"
        Me.txtA2.ReadOnly = True
        Me.txtA2.Size = New System.Drawing.Size(56, 20)
        Me.txtA2.TabIndex = 76
        Me.txtA2.TabStop = False
        '
        'txtA3
        '
        Me.txtA3.Location = New System.Drawing.Point(158, 74)
        Me.txtA3.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA3.Name = "txtA3"
        Me.txtA3.ReadOnly = True
        Me.txtA3.Size = New System.Drawing.Size(56, 20)
        Me.txtA3.TabIndex = 75
        Me.txtA3.TabStop = False
        '
        'txtA4
        '
        Me.txtA4.Location = New System.Drawing.Point(38, 96)
        Me.txtA4.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA4.Name = "txtA4"
        Me.txtA4.ReadOnly = True
        Me.txtA4.Size = New System.Drawing.Size(56, 20)
        Me.txtA4.TabIndex = 74
        Me.txtA4.TabStop = False
        '
        'txtA5
        '
        Me.txtA5.Location = New System.Drawing.Point(98, 96)
        Me.txtA5.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA5.Name = "txtA5"
        Me.txtA5.ReadOnly = True
        Me.txtA5.Size = New System.Drawing.Size(56, 20)
        Me.txtA5.TabIndex = 73
        Me.txtA5.TabStop = False
        '
        'txtA6
        '
        Me.txtA6.Location = New System.Drawing.Point(158, 96)
        Me.txtA6.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA6.Name = "txtA6"
        Me.txtA6.ReadOnly = True
        Me.txtA6.Size = New System.Drawing.Size(56, 20)
        Me.txtA6.TabIndex = 72
        Me.txtA6.TabStop = False
        '
        'txtA1
        '
        Me.txtA1.Location = New System.Drawing.Point(38, 74)
        Me.txtA1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtA1.Name = "txtA1"
        Me.txtA1.ReadOnly = True
        Me.txtA1.Size = New System.Drawing.Size(56, 20)
        Me.txtA1.TabIndex = 69
        Me.txtA1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(38, 29)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(70, 20)
        Me.Label1.TabIndex = 68
        Me.Label1.Text = "Matrix A:"
        '
        'btnQuit
        '
        Me.btnQuit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnQuit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuit.Location = New System.Drawing.Point(384, 150)
        Me.btnQuit.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(77, 40)
        Me.btnQuit.TabIndex = 7
        Me.btnQuit.Text = "Quit"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'btnHelp
        '
        Me.btnHelp.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHelp.Location = New System.Drawing.Point(287, 150)
        Me.btnHelp.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(77, 40)
        Me.btnHelp.TabIndex = 6
        Me.btnHelp.Text = "Help"
        Me.btnHelp.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(190, 150)
        Me.btnSubmit.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(77, 40)
        Me.btnSubmit.TabIndex = 5
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'frmMultMatrices2x3
        '
        Me.AcceptButton = Me.btnSubmit
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.CancelButton = Me.btnQuit
        Me.ClientSize = New System.Drawing.Size(652, 220)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.btnHelp)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.txtC2)
        Me.Controls.Add(Me.txtC3)
        Me.Controls.Add(Me.txtC4)
        Me.Controls.Add(Me.txtC1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtB6)
        Me.Controls.Add(Me.txtB2)
        Me.Controls.Add(Me.txtB3)
        Me.Controls.Add(Me.txtB4)
        Me.Controls.Add(Me.txtB5)
        Me.Controls.Add(Me.txtB1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtA2)
        Me.Controls.Add(Me.txtA3)
        Me.Controls.Add(Me.txtA4)
        Me.Controls.Add(Me.txtA5)
        Me.Controls.Add(Me.txtA6)
        Me.Controls.Add(Me.txtA1)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "frmMultMatrices2x3"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Multiplication 2x3"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtC2 As TextBox
    Friend WithEvents txtC3 As TextBox
    Friend WithEvents txtC4 As TextBox
    Friend WithEvents txtC1 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtB6 As TextBox
    Friend WithEvents txtB2 As TextBox
    Friend WithEvents txtB3 As TextBox
    Friend WithEvents txtB4 As TextBox
    Friend WithEvents txtB5 As TextBox
    Friend WithEvents txtB1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtA2 As TextBox
    Friend WithEvents txtA3 As TextBox
    Friend WithEvents txtA4 As TextBox
    Friend WithEvents txtA5 As TextBox
    Friend WithEvents txtA6 As TextBox
    Friend WithEvents txtA1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnQuit As Button
    Friend WithEvents btnHelp As Button
    Friend WithEvents btnSubmit As Button
End Class
