﻿Public Class frmSubMatrices3x3Endless
    Dim C1 As Decimal
    Dim C2 As Decimal
    Dim C3 As Decimal
    Dim C4 As Decimal
    Dim C5 As Decimal
    Dim C6 As Decimal
    Dim C7 As Decimal
    Dim C8 As Decimal
    Dim C9 As Decimal
    Dim correct As Boolean = True
    Dim i As Integer = 0
    'Checks submitted answers to correct answer for the matrix problem
    'Displays correct or incorrect message and returns to endless form
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Try
            If C1.Equals(CDec(txtC1.Text)) And C2.Equals(CDec(txtC2.Text)) And C3.Equals(CDec(txtC3.Text)) And C4.Equals(CDec(txtC4.Text)) And C5.Equals(CDec(txtC5.Text)) And C6.Equals(CDec(txtC6.Text)) And C7.Equals(CDec(txtC7.Text)) And C8.Equals(CDec(txtC8.Text)) And C9.Equals(CDec(txtC9.Text)) Then
                correct = True
            Else
                correct = False
            End If

            If correct = True Then
                frmEndlessTally.correct += 1
                Dim message As String = "You got it correct."
                Dim caption As String = "Correct!"
                Dim button As MessageBoxButtons = MessageBoxButtons.OK
                Dim correctMessage As DialogResult
                correctMessage = MessageBox.Show(message, caption, button)
                i += 1
            Else
                frmEndlessTally.incorrect += 1
                Dim message As String = "You got it incorrect."
                Dim caption As String = "Incorrect!"
                Dim button As MessageBoxButtons = MessageBoxButtons.OK
                Dim incorrectMessage As DialogResult
                incorrectMessage = MessageBox.Show(message, caption, button)
                i += 1
            End If

            If i = 1 Then

                frmRunningEndless.Show()
                Me.Close()

            End If

            If i = 1 Then
                frmLevelSelection.Show()
                Me.Close()
            End If

            frmSubMatrices3x3Endless_Load(e, e)
            txtC1.Clear()
            txtC2.Clear()
            txtC3.Clear()
            txtC4.Clear()
            txtC5.Clear()
            txtC6.Clear()
            txtC7.Clear()
            txtC8.Clear()
            txtC9.Clear()
            txtC1.Focus()
        Catch ex As InvalidCastException
            MessageBox.Show("Please enter only numbers.", "Error")
        Catch ex As ArgumentException
            MessageBox.Show("Please enter only numbers.", "Error")
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.StackTrace)
        End Try
    End Sub
    'Creates a random matrix problem based off of specified bounds
    Private Sub frmSubMatrices3x3Endless_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        txtA1.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA2.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA3.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA4.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA5.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA6.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA7.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA8.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtA9.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB1.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB2.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB3.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB4.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB5.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB6.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB7.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB8.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString
        txtB9.Text = (CInt(Math.Floor((20 - 1 + 1) * Rnd())) + 1).ToString

        C1 = (CDec(txtA1.Text) - CDec(txtB1.Text))
        C2 = (CDec(txtA2.Text) - CDec(txtB2.Text))
        C3 = (CDec(txtA3.Text) - CDec(txtB3.Text))
        C4 = (CDec(txtA4.Text) - CDec(txtB4.Text))
        C5 = (CDec(txtA5.Text) - CDec(txtB5.Text))
        C6 = (CDec(txtA6.Text) - CDec(txtB6.Text))
        C7 = (CDec(txtA7.Text) - CDec(txtB7.Text))
        C8 = (CDec(txtA8.Text) - CDec(txtB8.Text))
        C9 = (CDec(txtA9.Text) - CDec(txtB9.Text))
    End Sub
    'Displays the ending sequence for endless mode
    Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        frmExitEndless.Show()
        Me.Close()
    End Sub
    'Displays the help dialog box for subtraction
    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        dlgHelpSubtraction.Show()
    End Sub
End Class