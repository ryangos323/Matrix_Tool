﻿Public Class frmLevelSelection
    Public Property isStory As Boolean = False
    'Displays the help dialog box which explains the levels
    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        dlgLevelSelectionHelp.Show()
    End Sub
    'Tells the other forms that the current mode is story
    'Begins the story mode
    Private Sub btnStoryMode_Click(sender As Object, e As EventArgs) Handles btnStoryMode.Click
        isStory = True
        frmStoryModeSelect.Show()
        Me.Close()
    End Sub
    'Enter custom mode setup
    Private Sub btnCustomMode_Click(sender As Object, e As EventArgs) Handles btnCustomMode.Click
        frmCustomModeSetup.Show()
        Me.Close()
    End Sub
    ''Enters endless mode
    Private Sub btnEndlessMode_Click(sender As Object, e As EventArgs) Handles btnEndlessMode.Click
        frmRunningEndless.Show()
        Me.Close()

    End Sub
    'Displays top 5 high scores of the endless mode
    Private Sub btnHighScores_Click(sender As Object, e As EventArgs) Handles btnHighScores.Click
        frmHighScores.Show()
        Me.Close()
    End Sub

    'Private Sub frmLevelSelection_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    isStory = False
    'End Sub
End Class