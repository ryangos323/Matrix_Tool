﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLevelSelection
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnStoryMode = New System.Windows.Forms.Button()
        Me.btnHelp = New System.Windows.Forms.Button()
        Me.btnEndlessMode = New System.Windows.Forms.Button()
        Me.btnCustomMode = New System.Windows.Forms.Button()
        Me.btnHighScores = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.Font = New System.Drawing.Font("Showcard Gothic", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(17, 20)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(335, 30)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Please Choose a Game Mode:"
        '
        'btnStoryMode
        '
        Me.btnStoryMode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStoryMode.Location = New System.Drawing.Point(98, 54)
        Me.btnStoryMode.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnStoryMode.Name = "btnStoryMode"
        Me.btnStoryMode.Size = New System.Drawing.Size(143, 40)
        Me.btnStoryMode.TabIndex = 1
        Me.btnStoryMode.Text = "Story Mode"
        Me.btnStoryMode.UseVisualStyleBackColor = True
        '
        'btnHelp
        '
        Me.btnHelp.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHelp.Location = New System.Drawing.Point(98, 188)
        Me.btnHelp.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(143, 40)
        Me.btnHelp.TabIndex = 4
        Me.btnHelp.Text = "Help"
        Me.btnHelp.UseVisualStyleBackColor = True
        '
        'btnEndlessMode
        '
        Me.btnEndlessMode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEndlessMode.Location = New System.Drawing.Point(98, 144)
        Me.btnEndlessMode.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnEndlessMode.Name = "btnEndlessMode"
        Me.btnEndlessMode.Size = New System.Drawing.Size(143, 40)
        Me.btnEndlessMode.TabIndex = 3
        Me.btnEndlessMode.Text = "Endless Mode"
        Me.btnEndlessMode.UseVisualStyleBackColor = True
        '
        'btnCustomMode
        '
        Me.btnCustomMode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCustomMode.Location = New System.Drawing.Point(98, 99)
        Me.btnCustomMode.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnCustomMode.Name = "btnCustomMode"
        Me.btnCustomMode.Size = New System.Drawing.Size(143, 40)
        Me.btnCustomMode.TabIndex = 2
        Me.btnCustomMode.Text = "Custom Mode"
        Me.btnCustomMode.UseVisualStyleBackColor = True
        '
        'btnHighScores
        '
        Me.btnHighScores.Location = New System.Drawing.Point(246, 150)
        Me.btnHighScores.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnHighScores.Name = "btnHighScores"
        Me.btnHighScores.Size = New System.Drawing.Size(75, 28)
        Me.btnHighScores.TabIndex = 6
        Me.btnHighScores.Text = "High Scores"
        Me.btnHighScores.UseVisualStyleBackColor = True
        '
        'frmLevelSelection
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.ClientSize = New System.Drawing.Size(356, 248)
        Me.Controls.Add(Me.btnHighScores)
        Me.Controls.Add(Me.btnCustomMode)
        Me.Controls.Add(Me.btnEndlessMode)
        Me.Controls.Add(Me.btnHelp)
        Me.Controls.Add(Me.btnStoryMode)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "frmLevelSelection"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Mode Selection"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents btnStoryMode As Button
    Friend WithEvents btnHelp As Button
    Friend WithEvents btnEndlessMode As Button
    Friend WithEvents btnCustomMode As Button
    Friend WithEvents btnHighScores As Button
End Class
