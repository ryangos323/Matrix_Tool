﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddIntMatrices3x3Endless
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtC8 = New System.Windows.Forms.TextBox()
        Me.txtC2 = New System.Windows.Forms.TextBox()
        Me.txtC3 = New System.Windows.Forms.TextBox()
        Me.txtC4 = New System.Windows.Forms.TextBox()
        Me.txtC5 = New System.Windows.Forms.TextBox()
        Me.txtC6 = New System.Windows.Forms.TextBox()
        Me.txtC7 = New System.Windows.Forms.TextBox()
        Me.txtC9 = New System.Windows.Forms.TextBox()
        Me.txtC1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtB8 = New System.Windows.Forms.TextBox()
        Me.txtB2 = New System.Windows.Forms.TextBox()
        Me.txtB3 = New System.Windows.Forms.TextBox()
        Me.txtB4 = New System.Windows.Forms.TextBox()
        Me.txtB5 = New System.Windows.Forms.TextBox()
        Me.txtB6 = New System.Windows.Forms.TextBox()
        Me.txtB7 = New System.Windows.Forms.TextBox()
        Me.txtB9 = New System.Windows.Forms.TextBox()
        Me.txtB1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtA8 = New System.Windows.Forms.TextBox()
        Me.txtA2 = New System.Windows.Forms.TextBox()
        Me.txtA3 = New System.Windows.Forms.TextBox()
        Me.txtA4 = New System.Windows.Forms.TextBox()
        Me.txtA5 = New System.Windows.Forms.TextBox()
        Me.txtA6 = New System.Windows.Forms.TextBox()
        Me.txtA7 = New System.Windows.Forms.TextBox()
        Me.txtA9 = New System.Windows.Forms.TextBox()
        Me.txtA1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnQuit = New System.Windows.Forms.Button()
        Me.btnHelp = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtC8
        '
        Me.txtC8.Location = New System.Drawing.Point(605, 114)
        Me.txtC8.Margin = New System.Windows.Forms.Padding(2)
        Me.txtC8.Name = "txtC8"
        Me.txtC8.ReadOnly = True
        Me.txtC8.Size = New System.Drawing.Size(56, 20)
        Me.txtC8.TabIndex = 67
        Me.txtC8.TabStop = False
        '
        'txtC2
        '
        Me.txtC2.Location = New System.Drawing.Point(605, 69)
        Me.txtC2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtC2.Name = "txtC2"
        Me.txtC2.ReadOnly = True
        Me.txtC2.Size = New System.Drawing.Size(56, 20)
        Me.txtC2.TabIndex = 66
        Me.txtC2.TabStop = False
        '
        'txtC3
        '
        Me.txtC3.Location = New System.Drawing.Point(665, 69)
        Me.txtC3.Margin = New System.Windows.Forms.Padding(2)
        Me.txtC3.Name = "txtC3"
        Me.txtC3.ReadOnly = True
        Me.txtC3.Size = New System.Drawing.Size(56, 20)
        Me.txtC3.TabIndex = 65
        Me.txtC3.TabStop = False
        '
        'txtC4
        '
        Me.txtC4.Location = New System.Drawing.Point(545, 91)
        Me.txtC4.Margin = New System.Windows.Forms.Padding(2)
        Me.txtC4.Name = "txtC4"
        Me.txtC4.ReadOnly = True
        Me.txtC4.Size = New System.Drawing.Size(56, 20)
        Me.txtC4.TabIndex = 64
        Me.txtC4.TabStop = False
        '
        'txtC5
        '
        Me.txtC5.Location = New System.Drawing.Point(605, 91)
        Me.txtC5.Margin = New System.Windows.Forms.Padding(2)
        Me.txtC5.Name = "txtC5"
        Me.txtC5.ReadOnly = True
        Me.txtC5.Size = New System.Drawing.Size(56, 20)
        Me.txtC5.TabIndex = 63
        Me.txtC5.TabStop = False
        '
        'txtC6
        '
        Me.txtC6.Location = New System.Drawing.Point(665, 91)
        Me.txtC6.Margin = New System.Windows.Forms.Padding(2)
        Me.txtC6.Name = "txtC6"
        Me.txtC6.ReadOnly = True
        Me.txtC6.Size = New System.Drawing.Size(56, 20)
        Me.txtC6.TabIndex = 62
        Me.txtC6.TabStop = False
        '
        'txtC7
        '
        Me.txtC7.Location = New System.Drawing.Point(545, 114)
        Me.txtC7.Margin = New System.Windows.Forms.Padding(2)
        Me.txtC7.Name = "txtC7"
        Me.txtC7.ReadOnly = True
        Me.txtC7.Size = New System.Drawing.Size(56, 20)
        Me.txtC7.TabIndex = 61
        Me.txtC7.TabStop = False
        '
        'txtC9
        '
        Me.txtC9.Location = New System.Drawing.Point(665, 114)
        Me.txtC9.Margin = New System.Windows.Forms.Padding(2)
        Me.txtC9.Name = "txtC9"
        Me.txtC9.ReadOnly = True
        Me.txtC9.Size = New System.Drawing.Size(56, 20)
        Me.txtC9.TabIndex = 60
        Me.txtC9.TabStop = False
        '
        'txtC1
        '
        Me.txtC1.Location = New System.Drawing.Point(545, 69)
        Me.txtC1.Margin = New System.Windows.Forms.Padding(2)
        Me.txtC1.Name = "txtC1"
        Me.txtC1.ReadOnly = True
        Me.txtC1.Size = New System.Drawing.Size(56, 20)
        Me.txtC1.TabIndex = 59
        Me.txtC1.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(543, 32)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(70, 20)
        Me.Label5.TabIndex = 56
        Me.Label5.Text = "Matrix C:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(492, 79)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(30, 31)
        Me.Label4.TabIndex = 55
        Me.Label4.Text = "="
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(244, 79)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 31)
        Me.Label3.TabIndex = 54
        Me.Label3.Text = "+"
        '
        'txtB8
        '
        Me.txtB8.Location = New System.Drawing.Point(357, 114)
        Me.txtB8.Margin = New System.Windows.Forms.Padding(2)
        Me.txtB8.Name = "txtB8"
        Me.txtB8.Size = New System.Drawing.Size(56, 20)
        Me.txtB8.TabIndex = 8
        '
        'txtB2
        '
        Me.txtB2.Location = New System.Drawing.Point(357, 69)
        Me.txtB2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtB2.Name = "txtB2"
        Me.txtB2.Size = New System.Drawing.Size(56, 20)
        Me.txtB2.TabIndex = 2
        '
        'txtB3
        '
        Me.txtB3.Location = New System.Drawing.Point(417, 69)
        Me.txtB3.Margin = New System.Windows.Forms.Padding(2)
        Me.txtB3.Name = "txtB3"
        Me.txtB3.Size = New System.Drawing.Size(56, 20)
        Me.txtB3.TabIndex = 3
        '
        'txtB4
        '
        Me.txtB4.Location = New System.Drawing.Point(297, 91)
        Me.txtB4.Margin = New System.Windows.Forms.Padding(2)
        Me.txtB4.Name = "txtB4"
        Me.txtB4.Size = New System.Drawing.Size(56, 20)
        Me.txtB4.TabIndex = 4
        '
        'txtB5
        '
        Me.txtB5.Location = New System.Drawing.Point(357, 91)
        Me.txtB5.Margin = New System.Windows.Forms.Padding(2)
        Me.txtB5.Name = "txtB5"
        Me.txtB5.Size = New System.Drawing.Size(56, 20)
        Me.txtB5.TabIndex = 5
        '
        'txtB6
        '
        Me.txtB6.Location = New System.Drawing.Point(417, 91)
        Me.txtB6.Margin = New System.Windows.Forms.Padding(2)
        Me.txtB6.Name = "txtB6"
        Me.txtB6.Size = New System.Drawing.Size(56, 20)
        Me.txtB6.TabIndex = 6
        '
        'txtB7
        '
        Me.txtB7.Location = New System.Drawing.Point(297, 114)
        Me.txtB7.Margin = New System.Windows.Forms.Padding(2)
        Me.txtB7.Name = "txtB7"
        Me.txtB7.Size = New System.Drawing.Size(56, 20)
        Me.txtB7.TabIndex = 7
        '
        'txtB9
        '
        Me.txtB9.Location = New System.Drawing.Point(417, 114)
        Me.txtB9.Margin = New System.Windows.Forms.Padding(2)
        Me.txtB9.Name = "txtB9"
        Me.txtB9.Size = New System.Drawing.Size(56, 20)
        Me.txtB9.TabIndex = 9
        '
        'txtB1
        '
        Me.txtB1.Location = New System.Drawing.Point(297, 69)
        Me.txtB1.Margin = New System.Windows.Forms.Padding(2)
        Me.txtB1.Name = "txtB1"
        Me.txtB1.Size = New System.Drawing.Size(56, 20)
        Me.txtB1.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(294, 32)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(136, 20)
        Me.Label2.TabIndex = 44
        Me.Label2.Text = "Solve for Matrix B:"
        '
        'txtA8
        '
        Me.txtA8.Location = New System.Drawing.Point(104, 114)
        Me.txtA8.Margin = New System.Windows.Forms.Padding(2)
        Me.txtA8.Name = "txtA8"
        Me.txtA8.ReadOnly = True
        Me.txtA8.Size = New System.Drawing.Size(56, 20)
        Me.txtA8.TabIndex = 43
        Me.txtA8.TabStop = False
        '
        'txtA2
        '
        Me.txtA2.Location = New System.Drawing.Point(104, 69)
        Me.txtA2.Margin = New System.Windows.Forms.Padding(2)
        Me.txtA2.Name = "txtA2"
        Me.txtA2.ReadOnly = True
        Me.txtA2.Size = New System.Drawing.Size(56, 20)
        Me.txtA2.TabIndex = 42
        Me.txtA2.TabStop = False
        '
        'txtA3
        '
        Me.txtA3.Location = New System.Drawing.Point(164, 69)
        Me.txtA3.Margin = New System.Windows.Forms.Padding(2)
        Me.txtA3.Name = "txtA3"
        Me.txtA3.ReadOnly = True
        Me.txtA3.Size = New System.Drawing.Size(56, 20)
        Me.txtA3.TabIndex = 41
        Me.txtA3.TabStop = False
        '
        'txtA4
        '
        Me.txtA4.Location = New System.Drawing.Point(44, 91)
        Me.txtA4.Margin = New System.Windows.Forms.Padding(2)
        Me.txtA4.Name = "txtA4"
        Me.txtA4.ReadOnly = True
        Me.txtA4.Size = New System.Drawing.Size(56, 20)
        Me.txtA4.TabIndex = 40
        Me.txtA4.TabStop = False
        '
        'txtA5
        '
        Me.txtA5.Location = New System.Drawing.Point(104, 91)
        Me.txtA5.Margin = New System.Windows.Forms.Padding(2)
        Me.txtA5.Name = "txtA5"
        Me.txtA5.ReadOnly = True
        Me.txtA5.Size = New System.Drawing.Size(56, 20)
        Me.txtA5.TabIndex = 39
        Me.txtA5.TabStop = False
        '
        'txtA6
        '
        Me.txtA6.Location = New System.Drawing.Point(164, 91)
        Me.txtA6.Margin = New System.Windows.Forms.Padding(2)
        Me.txtA6.Name = "txtA6"
        Me.txtA6.ReadOnly = True
        Me.txtA6.Size = New System.Drawing.Size(56, 20)
        Me.txtA6.TabIndex = 38
        Me.txtA6.TabStop = False
        '
        'txtA7
        '
        Me.txtA7.Location = New System.Drawing.Point(44, 114)
        Me.txtA7.Margin = New System.Windows.Forms.Padding(2)
        Me.txtA7.Name = "txtA7"
        Me.txtA7.ReadOnly = True
        Me.txtA7.Size = New System.Drawing.Size(56, 20)
        Me.txtA7.TabIndex = 37
        Me.txtA7.TabStop = False
        '
        'txtA9
        '
        Me.txtA9.Location = New System.Drawing.Point(164, 114)
        Me.txtA9.Margin = New System.Windows.Forms.Padding(2)
        Me.txtA9.Name = "txtA9"
        Me.txtA9.ReadOnly = True
        Me.txtA9.Size = New System.Drawing.Size(56, 20)
        Me.txtA9.TabIndex = 36
        Me.txtA9.TabStop = False
        '
        'txtA1
        '
        Me.txtA1.Location = New System.Drawing.Point(44, 69)
        Me.txtA1.Margin = New System.Windows.Forms.Padding(2)
        Me.txtA1.Name = "txtA1"
        Me.txtA1.ReadOnly = True
        Me.txtA1.Size = New System.Drawing.Size(56, 20)
        Me.txtA1.TabIndex = 35
        Me.txtA1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(41, 32)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(70, 20)
        Me.Label1.TabIndex = 34
        Me.Label1.Text = "Matrix A:"
        '
        'btnQuit
        '
        Me.btnQuit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnQuit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuit.Location = New System.Drawing.Point(439, 147)
        Me.btnQuit.Margin = New System.Windows.Forms.Padding(2)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(77, 40)
        Me.btnQuit.TabIndex = 12
        Me.btnQuit.Text = "Quit"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'btnHelp
        '
        Me.btnHelp.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHelp.Location = New System.Drawing.Point(342, 147)
        Me.btnHelp.Margin = New System.Windows.Forms.Padding(2)
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(77, 40)
        Me.btnHelp.TabIndex = 11
        Me.btnHelp.Text = "Help"
        Me.btnHelp.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(245, 147)
        Me.btnSubmit.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(77, 40)
        Me.btnSubmit.TabIndex = 10
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'frmAddIntMatrices3x3Endless
        '
        Me.AcceptButton = Me.btnSubmit
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.CancelButton = Me.btnQuit
        Me.ClientSize = New System.Drawing.Size(761, 219)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.btnHelp)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.txtC8)
        Me.Controls.Add(Me.txtC2)
        Me.Controls.Add(Me.txtC3)
        Me.Controls.Add(Me.txtC4)
        Me.Controls.Add(Me.txtC5)
        Me.Controls.Add(Me.txtC6)
        Me.Controls.Add(Me.txtC7)
        Me.Controls.Add(Me.txtC9)
        Me.Controls.Add(Me.txtC1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtB8)
        Me.Controls.Add(Me.txtB2)
        Me.Controls.Add(Me.txtB3)
        Me.Controls.Add(Me.txtB4)
        Me.Controls.Add(Me.txtB5)
        Me.Controls.Add(Me.txtB6)
        Me.Controls.Add(Me.txtB7)
        Me.Controls.Add(Me.txtB9)
        Me.Controls.Add(Me.txtB1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtA8)
        Me.Controls.Add(Me.txtA2)
        Me.Controls.Add(Me.txtA3)
        Me.Controls.Add(Me.txtA4)
        Me.Controls.Add(Me.txtA5)
        Me.Controls.Add(Me.txtA6)
        Me.Controls.Add(Me.txtA7)
        Me.Controls.Add(Me.txtA9)
        Me.Controls.Add(Me.txtA1)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmAddIntMatrices3x3Endless"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Intermediate Addition 3x3"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtC8 As TextBox
    Friend WithEvents txtC2 As TextBox
    Friend WithEvents txtC3 As TextBox
    Friend WithEvents txtC4 As TextBox
    Friend WithEvents txtC5 As TextBox
    Friend WithEvents txtC6 As TextBox
    Friend WithEvents txtC7 As TextBox
    Friend WithEvents txtC9 As TextBox
    Friend WithEvents txtC1 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtB8 As TextBox
    Friend WithEvents txtB2 As TextBox
    Friend WithEvents txtB3 As TextBox
    Friend WithEvents txtB4 As TextBox
    Friend WithEvents txtB5 As TextBox
    Friend WithEvents txtB6 As TextBox
    Friend WithEvents txtB7 As TextBox
    Friend WithEvents txtB9 As TextBox
    Friend WithEvents txtB1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtA8 As TextBox
    Friend WithEvents txtA2 As TextBox
    Friend WithEvents txtA3 As TextBox
    Friend WithEvents txtA4 As TextBox
    Friend WithEvents txtA5 As TextBox
    Friend WithEvents txtA6 As TextBox
    Friend WithEvents txtA7 As TextBox
    Friend WithEvents txtA9 As TextBox
    Friend WithEvents txtA1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnQuit As Button
    Friend WithEvents btnHelp As Button
    Friend WithEvents btnSubmit As Button
End Class
