﻿Public Class frmCustomModeSetup
    Private Sub btnIntermediateHelp_Click(sender As Object, e As EventArgs) Handles btnIntermediateHelp.Click
        dlgIntermediateHelp.Show()
    End Sub

    Friend Sub ques()
        Throw New NotImplementedException()
    End Sub
    'Returns to level selection page
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        frmLevelSelection.Show()
        Me.Close()
    End Sub
    'Opens custom mode page for addition
    Private Sub btnAddition_Click(sender As Object, e As EventArgs) Handles btnAddition.Click
        frmCustomModeSetupAddition.Show()
        Me.Close()
    End Sub
    'Opens custom mode page for subtraction
    Private Sub btnSubtraction_Click(sender As Object, e As EventArgs) Handles btnSubtraction.Click
        frmCustomModeSetupSubtraction.Show()
        Me.Close()
    End Sub
    'Opens custom mode page for multiplication
    Private Sub btnMultiplication_Click(sender As Object, e As EventArgs) Handles btnMultiplication.Click
        frmCustomModeSetupMultiplication.Show()
        Me.Close()
    End Sub
    'Opens custom mode page for intermediate
    Private Sub btnIntermediate_Click(sender As Object, e As EventArgs) Handles btnIntermediate.Click
        frmCustomModeSetupIntermediate.Show()
        Me.Close()
    End Sub
End Class