﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCustomModeSetup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnAddition = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnSubtraction = New System.Windows.Forms.Button()
        Me.btnMultiplication = New System.Windows.Forms.Button()
        Me.btnIntermediate = New System.Windows.Forms.Button()
        Me.btnIntermediateHelp = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnAddition
        '
        Me.btnAddition.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddition.Location = New System.Drawing.Point(108, 82)
        Me.btnAddition.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnAddition.Name = "btnAddition"
        Me.btnAddition.Size = New System.Drawing.Size(197, 49)
        Me.btnAddition.TabIndex = 1
        Me.btnAddition.Text = "Addition"
        Me.btnAddition.UseVisualStyleBackColor = True
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(317, 299)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(97, 31)
        Me.btnBack.TabIndex = 6
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(39, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(340, 25)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "What matrix operation would you like?"
        '
        'btnSubtraction
        '
        Me.btnSubtraction.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubtraction.Location = New System.Drawing.Point(108, 137)
        Me.btnSubtraction.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSubtraction.Name = "btnSubtraction"
        Me.btnSubtraction.Size = New System.Drawing.Size(197, 49)
        Me.btnSubtraction.TabIndex = 2
        Me.btnSubtraction.Text = "Subtraction"
        Me.btnSubtraction.UseVisualStyleBackColor = True
        '
        'btnMultiplication
        '
        Me.btnMultiplication.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMultiplication.Location = New System.Drawing.Point(108, 192)
        Me.btnMultiplication.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnMultiplication.Name = "btnMultiplication"
        Me.btnMultiplication.Size = New System.Drawing.Size(197, 49)
        Me.btnMultiplication.TabIndex = 3
        Me.btnMultiplication.Text = "Multiplication"
        Me.btnMultiplication.UseVisualStyleBackColor = True
        '
        'btnIntermediate
        '
        Me.btnIntermediate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnIntermediate.Location = New System.Drawing.Point(108, 247)
        Me.btnIntermediate.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnIntermediate.Name = "btnIntermediate"
        Me.btnIntermediate.Size = New System.Drawing.Size(197, 49)
        Me.btnIntermediate.TabIndex = 4
        Me.btnIntermediate.Text = "Intermediate"
        Me.btnIntermediate.UseVisualStyleBackColor = True
        '
        'btnIntermediateHelp
        '
        Me.btnIntermediateHelp.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnIntermediateHelp.Location = New System.Drawing.Point(312, 252)
        Me.btnIntermediateHelp.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnIntermediateHelp.Name = "btnIntermediateHelp"
        Me.btnIntermediateHelp.Size = New System.Drawing.Size(41, 39)
        Me.btnIntermediateHelp.TabIndex = 5
        Me.btnIntermediateHelp.Text = "?"
        Me.btnIntermediateHelp.UseVisualStyleBackColor = True
        '
        'frmCustomModeSetup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.ClientSize = New System.Drawing.Size(419, 334)
        Me.Controls.Add(Me.btnIntermediateHelp)
        Me.Controls.Add(Me.btnIntermediate)
        Me.Controls.Add(Me.btnMultiplication)
        Me.Controls.Add(Me.btnSubtraction)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.btnAddition)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "frmCustomModeSetup"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Custom Mode Setup"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnAddition As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents btnSubtraction As Button
    Friend WithEvents btnMultiplication As Button
    Friend WithEvents btnIntermediate As Button
    Friend WithEvents btnIntermediateHelp As Button
End Class
