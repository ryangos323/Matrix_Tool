﻿Public Class frmMainScreen
    'Enters the level selection form of the matrix game
    Private Sub btnBegin_Click(sender As Object, e As EventArgs) Handles btnBegin.Click
        frmLevelSelection.Show()
        Me.Close()
    End Sub
    'Exits the game
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
