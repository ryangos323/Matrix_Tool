﻿Imports System.IO
Public Class frmHighScores
    'Displays the list of high scores from the text files
    Private Sub frmHighScores_Load(sender As Object, e As EventArgs) Handles MyBase.Load, MyBase.Shown
        Dim reader As New StreamReader("HighScores.txt")
        Dim scores(5) As String
        For q As Integer = 0 To 4
            scores(q) = reader.ReadLine()
        Next q
        reader.Close()
        Dim counter As Integer = 0

        lblScore1.Text = scores(counter)
        counter += 1
        lblScore2.Text = scores(counter)
        counter += 1
        lblScore3.Text = scores(counter)
        counter += 1
        lblScore4.Text = scores(counter)
        counter += 1
        lblScore5.Text = scores(counter)
        counter += 1
    End Sub
    'Returns to the level selection page
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        frmLevelSelection.Show()
        Me.Close()
    End Sub
End Class